<?php
declare(strict_types=1);

date_default_timezone_set('Asia/Makassar');

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ]);
    session_start();
}

function db(): PDO
{
    static $pdo;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $requestHost = strtolower(trim((string) ($_SERVER['HTTP_HOST'] ?? ''), '[]'));
    $requestHost = preg_replace('/:\d+$/', '', $requestHost);
    $serverAddress = (string) ($_SERVER['SERVER_ADDR'] ?? '');
    $isPrivateServer = $serverAddress !== ''
        && filter_var($serverAddress, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false;
    $isLocal = in_array($requestHost, ['localhost', '127.0.0.1', '::1'], true) || $isPrivateServer;

    $host = getenv('DB_HOST');
    $name = getenv('DB_NAME');
    $user = getenv('DB_USER');
    $pass = getenv('DB_PASS');
    if ($isLocal) {
        $host = $host !== false && $host !== '' ? $host : '127.0.0.1';
        $name = $name !== false && $name !== '' ? $name : 'lms_smkn1_parepare';
        $user = $user !== false && $user !== '' ? $user : 'root';
        $pass = $pass === false ? '' : $pass;
    } elseif (!$host || !$name || !$user || ($pass === false && getenv('DB_PASS_EMPTY') !== '1')) {
        throw new RuntimeException('Konfigurasi database hosting harus diatur melalui environment DB_HOST, DB_NAME, DB_USER, dan DB_PASS.');
    }
    if (getenv('DB_PASS_EMPTY') === '1') {
        $pass = '';
    }

    $pdo = new PDO(
        "mysql:host={$host};dbname={$name};charset=utf8mb4",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
    $pdo->exec("SET time_zone = '+08:00'");

    return $pdo;
}

function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!is_string($token) || !hash_equals(csrf_token(), $token)) {
        http_response_code(419);
        exit('Sesi formulir tidak valid. Muat ulang halaman, lalu coba lagi.');
    }
}

function redirect(string $url = 'index.php'): void
{
    header('Location: ' . $url);
    exit;
}

function current_user(): ?array
{
    return $_SESSION['user'] ?? null;
}

function require_role(string ...$roles): array
{
    $user = current_user();
    if (!$user) {
        redirect('index.php');
    }
    if (!in_array($user['role'], $roles, true)) {
        http_response_code(403);
        exit('Anda tidak memiliki akses ke halaman ini.');
    }
    return $user;
}

function set_flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function take_flash(): ?array
{
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $flash;
}