<?php
declare(strict_types=1);

require __DIR__ . '/lms.php';
exit;

function date_label(?string $date): string
{
    if (!$date) {
        return 'Tanpa tenggat';
    }
    $time = strtotime($date);
    $months = [1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    return $time ? date('d', $time) . ' ' . $months[(int) date('n', $time)] . date(' Y, H:i', $time) : 'Tanpa tenggat';
}

function today_label(): string
{
    $days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    $months = [1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    return $days[(int) date('w')] . ', ' . date('d') . ' ' . $months[(int) date('n')] . ' ' . date('Y');
}

function role_label(string $role): string
{
    return ['admin' => 'Admin', 'teacher' => 'Guru', 'student' => 'Siswa'][$role] ?? $role;
}

try {
    $pdo = db();
} catch (Throwable $exception) {
    http_response_code(503);
    ?>
    <!doctype html>
    <html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>LMS belum disiapkan</title><link rel="stylesheet" href="assets/style.css"></head>
    <body class="install-page"><main class="install-card"><div class="brand-mark">L</div><p class="eyebrow">SMAN 1 PAREPARE · LMS</p><h1>Database belum siap.</h1><p class="muted">Jalankan installer sekali untuk membuat database dan akun demo.</p><a class="button button-primary button-wide" href="install.php">Buka installer <span aria-hidden="true">↗</span></a></main></body></html>
    <?php
    exit;
}

if (isset($_GET['download'])) {
    $user = current_user();
    if (!$user) {
        redirect();
    }
    $statement = $pdo->prepare(
        'SELECT s.*, a.title, c.teacher_id FROM submissions s
         JOIN assignments a ON a.id = s.assignment_id
         JOIN courses c ON c.id = a.course_id WHERE s.id = ?'
    );
    $statement->execute([(int) $_GET['download']]);
    $submission = $statement->fetch();
    $allowed = $submission && (
        $user['role'] === 'admin'
        || ($user['role'] === 'student' && (int) $submission['student_id'] === (int) $user['id'])
        || ($user['role'] === 'teacher' && (int) $submission['teacher_id'] === (int) $user['id'])
    );
    if (!$allowed) {
        http_response_code(403);
        exit('Anda tidak memiliki akses ke berkas ini.');
    }
    $stored = (string) $submission['file_stored'];
    if (!preg_match('/^[a-f0-9]{32}\.[a-z0-9]{1,10}$/', $stored)) {
        http_response_code(404);
        exit('Berkas tidak ditemukan.');
    }
    $path = __DIR__ . '/storage/uploads/' . $stored;
    if (!is_file($path)) {
        http_response_code(404);
        exit('Berkas tidak ditemukan.');
    }
    $filename = str_replace(["\r", "\n", '"'], '', basename((string) $submission['file_original']));
    header('Content-Type: application/octet-stream');
    header('Content-Length: ' . (string) filesize($path));
    header('Content-Disposition: attachment; filename="' . addcslashes($filename, '\\') . '"; filename*=UTF-8\'\'' . rawurlencode($filename));
    readfile($path);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'login') {
        $statement = $pdo->prepare('SELECT id, name, username, password_hash, role FROM users WHERE username = ? LIMIT 1');
        $statement->execute([trim((string) ($_POST['username'] ?? ''))]);
        $account = $statement->fetch();
        if ($account && password_verify((string) ($_POST['password'] ?? ''), $account['password_hash'])) {
            session_regenerate_id(true);
            unset($account['password_hash']);
            $_SESSION['user'] = $account;
            redirect();
        }
        set_flash('error', 'Username atau password tidak sesuai.');
        redirect();
    }

    if ($action === 'logout') {
        $_SESSION = [];
        session_regenerate_id(true);
        redirect();
    }

    $user = require_role('admin', 'teacher', 'student');
    try {
        switch ($action) {
            case 'create_user':
                require_role('admin');
                $name = trim((string) ($_POST['name'] ?? ''));
                $username = trim((string) ($_POST['username'] ?? ''));
                $password = (string) ($_POST['password'] ?? '');
                $role = (string) ($_POST['role'] ?? '');
                if ($name === '' || !preg_match('/^[A-Za-z0-9._-]{3,60}$/', $username) || strlen($password) < 4 || !in_array($role, ['teacher', 'student'], true)) {
                    throw new RuntimeException('Lengkapi nama, username (3-60 karakter), password (minimal 4 karakter), dan peran yang valid.');
                }
                $statement = $pdo->prepare('INSERT INTO users (name, username, password_hash, role) VALUES (?, ?, ?, ?)');
                $statement->execute([$name, $username, password_hash($password, PASSWORD_DEFAULT), $role]);
                set_flash('success', 'Akun baru berhasil dibuat.');
                break;

            case 'delete_user':
                require_role('admin');
                $target = (int) ($_POST['user_id'] ?? 0);
                if ($target === (int) $user['id']) {
                    throw new RuntimeException('Akun yang sedang digunakan tidak dapat dihapus.');
                }
                $statement = $pdo->prepare('DELETE FROM users WHERE id = ? AND role <> "admin"');
                $statement->execute([$target]);
                set_flash($statement->rowCount() ? 'success' : 'error', $statement->rowCount() ? 'Akun berhasil dihapus.' : 'Akun tidak ditemukan atau tidak dapat dihapus.');
                break;

            case 'create_course':
                require_role('admin');
                $name = trim((string) ($_POST['name'] ?? ''));
                $code = strtoupper(trim((string) ($_POST['code'] ?? '')));
                $teacherId = (int) ($_POST['teacher_id'] ?? 0);
                if ($name === '' || !preg_match('/^[A-Z0-9-]{2,30}$/', $code)) {
                    throw new RuntimeException('Nama mata pelajaran dan kode 2-30 karakter wajib diisi.');
                }
                $teacherCheck = $pdo->prepare('SELECT id FROM users WHERE id = ? AND role = "teacher"');
                $teacherCheck->execute([$teacherId]);
                if (!$teacherCheck->fetch()) {
                    throw new RuntimeException('Pilih akun guru yang valid.');
                }
                $statement = $pdo->prepare('INSERT INTO courses (name, code, teacher_id) VALUES (?, ?, ?)');
                $statement->execute([$name, $code, $teacherId]);
                set_flash('success', 'Mata pelajaran berhasil ditambahkan.');
                break;

            case 'create_assignment':
                $teacher = require_role('teacher');
                $courseId = (int) ($_POST['course_id'] ?? 0);
                $title = trim((string) ($_POST['title'] ?? ''));
                $description = trim((string) ($_POST['description'] ?? ''));
                $dueInput = trim((string) ($_POST['due_date'] ?? ''));
                if ($title === '' || $description === '') {
                    throw new RuntimeException('Judul dan instruksi tugas wajib diisi.');
                }
                $courseCheck = $pdo->prepare('SELECT id FROM courses WHERE id = ? AND teacher_id = ?');
                $courseCheck->execute([$courseId, $teacher['id']]);
                if (!$courseCheck->fetch()) {
                    throw new RuntimeException('Mata pelajaran tidak ditemukan atau bukan tanggung jawab Anda.');
                }
                $dueDate = null;
                if ($dueInput !== '') {
                    $parsed = DateTime::createFromFormat('Y-m-d\TH:i', $dueInput);
                    if (!$parsed) {
                        throw new RuntimeException('Format tenggat tidak valid.');
                    }
                    $dueDate = $parsed->format('Y-m-d H:i:s');
                }
                $statement = $pdo->prepare('INSERT INTO assignments (course_id, title, description, due_date) VALUES (?, ?, ?, ?)');
                $statement->execute([$courseId, $title, $description, $dueDate]);
                set_flash('success', 'Tugas berhasil diterbitkan.');
                break;

            case 'grade_submission':
                $teacher = require_role('teacher');
                $submissionId = (int) ($_POST['submission_id'] ?? 0);
                $scoreInput = trim((string) ($_POST['score'] ?? ''));
                $feedback = trim((string) ($_POST['feedback'] ?? ''));
                if (!is_numeric($scoreInput) || (float) $scoreInput < 0 || (float) $scoreInput > 100) {
                    throw new RuntimeException('Nilai harus berupa angka dari 0 sampai 100.');
                }
                $statement = $pdo->prepare(
                    'UPDATE submissions s JOIN assignments a ON a.id = s.assignment_id JOIN courses c ON c.id = a.course_id
                     SET s.score = ?, s.feedback = ?, s.graded_by = ?, s.graded_at = NOW()
                     WHERE s.id = ? AND c.teacher_id = ?'
                );
                $statement->execute([(float) $scoreInput, $feedback, $teacher['id'], $submissionId, $teacher['id']]);
                if (!$statement->rowCount()) {
                    $exists = $pdo->prepare('SELECT s.score FROM submissions s JOIN assignments a ON a.id = s.assignment_id JOIN courses c ON c.id = a.course_id WHERE s.id = ? AND c.teacher_id = ?');
                    $exists->execute([$submissionId, $teacher['id']]);
                    if (!$exists->fetch()) {
                        throw new RuntimeException('Tugas siswa tidak ditemukan atau bukan tanggung jawab Anda.');
                    }
                }
                set_flash('success', 'Penilaian berhasil disimpan.');
                break;

            case 'submit_assignment':
                $student = require_role('student');
                $assignmentId = (int) ($_POST['assignment_id'] ?? 0);
                $assignmentCheck = $pdo->prepare('SELECT id FROM assignments WHERE id = ?');
                $assignmentCheck->execute([$assignmentId]);
                if (!$assignmentCheck->fetch()) {
                    throw new RuntimeException('Tugas tidak ditemukan.');
                }
                $upload = $_FILES['submission_file'] ?? null;
                if (!$upload || $upload['error'] !== UPLOAD_ERR_OK || $upload['size'] > 10 * 1024 * 1024) {
                    throw new RuntimeException('Pilih berkas maksimal 10 MB dan unggah kembali.');
                }
                $originalName = basename((string) $upload['name']);
                $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
                $allowedExtensions = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'jpg', 'jpeg', 'png'];
                if (!in_array($extension, $allowedExtensions, true)) {
                    throw new RuntimeException('Format berkas yang diterima: PDF, Word, Excel, PowerPoint, JPG, atau PNG.');
                }
                $storedName = bin2hex(random_bytes(16)) . '.' . $extension;
                $uploadDirectory = __DIR__ . '/storage/uploads';
                if (!is_dir($uploadDirectory) && !mkdir($uploadDirectory, 0750, true) && !is_dir($uploadDirectory)) {
                    throw new RuntimeException('Folder penyimpanan tidak dapat dibuat.');
                }
                $destination = $uploadDirectory . '/' . $storedName;
                if (!move_uploaded_file($upload['tmp_name'], $destination)) {
                    throw new RuntimeException('Berkas gagal disimpan. Periksa izin folder storage/uploads.');
                }
                $old = $pdo->prepare('SELECT file_stored FROM submissions WHERE assignment_id = ? AND student_id = ?');
                $old->execute([$assignmentId, $student['id']]);
                $oldFile = $old->fetchColumn();
                $statement = $pdo->prepare(
                    'INSERT INTO submissions (assignment_id, student_id, file_original, file_stored, submitted_at, score, feedback, graded_by, graded_at)
                     VALUES (?, ?, ?, ?, NOW(), NULL, NULL, NULL, NULL)
                     ON DUPLICATE KEY UPDATE file_original = VALUES(file_original), file_stored = VALUES(file_stored), submitted_at = NOW(), score = NULL, feedback = NULL, graded_by = NULL, graded_at = NULL'
                );
                $statement->execute([$assignmentId, $student['id'], $originalName, $storedName]);
                if ($oldFile) {
                    $oldPath = $uploadDirectory . '/' . basename((string) $oldFile);
                    if (is_file($oldPath)) {
                        unlink($oldPath);
                    }
                }
                set_flash('success', 'Tugas berhasil dikumpulkan. Nilai sebelumnya akan diperbarui setelah guru menilai ulang.');
                break;

            default:
                throw new RuntimeException('Aksi tidak dikenali.');
        }
    } catch (RuntimeException $exception) {
        set_flash('error', $exception->getMessage());
    } catch (PDOException $exception) {
        $message = $exception->getCode() === '23000'
            ? 'Username atau kode mata pelajaran sudah digunakan, atau data masih terhubung dengan aktivitas lain.'
            : 'Perubahan tidak dapat disimpan. Periksa kembali data dan koneksi database.';
        set_flash('error', $message);
    } catch (Throwable $exception) {
        set_flash('error', 'Terjadi kesalahan saat memproses permintaan.');
    }
    redirect();
}

$user = current_user();
$flash = take_flash();
if (!$user) {
    ?>
    <!doctype html>
    <html lang="id">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#f3f5ef">
        <title>Masuk | LMS SMAN 1 Parepare</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="assets/style.css">
    </head>
    <body class="login-page">
        <div class="login-shell">
            <section class="login-art" aria-label="LMS SMAN 1 Parepare">
                <div class="art-top"><span class="brand-mark brand-mark-light">L</span><span>SMAN 1 PAREPARE</span></div>
                <div class="art-content">
                    <p class="eyebrow">LEARNING MANAGEMENT SYSTEM</p>
                    <h1>Belajar hari ini.<br><em>Siap esok hari.</em></h1>
                    <p>Ruang belajar Bahasa Inggris untuk tumbuh, berkarya, dan melangkah lebih jauh.</p>
                </div>
                <div class="art-bottom"><span>01</span><span class="art-rule"></span><span>RUANG KELAS DIGITAL</span></div>
                <div class="art-shape shape-one"></div><div class="art-shape shape-two"></div>
            </section>
            <section class="login-panel">
                <div class="mobile-brand"><span class="brand-mark">L</span><span>SMAN 1 PAREPARE</span></div>
                <div class="login-form-wrap">
                    <p class="eyebrow">SELAMAT DATANG KEMBALI</p>
                    <h2>Masuk ke LMS</h2>
                    <p class="muted">Gunakan akun sekolah untuk melanjutkan.</p>
                    <?php if ($flash): ?><div class="notice notice-<?= e($flash['type']) ?>" role="status"><?= e($flash['message']) ?></div><?php endif; ?>
                    <form method="post" class="form-stack">
                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                        <input type="hidden" name="action" value="login">
                        <label for="username">Username</label>
                        <input id="username" name="username" type="text" autocomplete="username" placeholder="Masukkan username" required autofocus>
                        <label for="password">Password</label>
                        <div class="password-field"><input id="password" name="password" type="password" autocomplete="current-password" placeholder="Masukkan password" required><button type="button" class="password-toggle" aria-label="Tampilkan password" title="Tampilkan password">Lihat</button></div>
                        <button class="button button-dark button-wide" type="submit">Masuk <span aria-hidden="true">↗</span></button>
                    </form>
                    <div class="demo-accounts"><span class="demo-label">AKUN DEMO</span><span>Admin <b>admin / admin</b></span><span>Guru <b>guru / guru</b></span><span>Siswa <b>siswa / siswa</b></span></div>
                    <p class="login-foot">© <?= date('Y') ?> SMAN 1 Parepare</p>
                </div>
            </section>
        </div>
        <script src="assets/app.js" defer></script>
    </body>
    </html>
    <?php
    exit;
}

$role = $user['role'];
$overview = [];
$courses = [];
$assignments = [];
$submissions = [];
$users = [];
$teachers = [];

if ($role === 'admin') {
    $overview = [
        'Akun pengguna' => (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn(),
        'Mata pelajaran' => (int) $pdo->query('SELECT COUNT(*) FROM courses')->fetchColumn(),
        'Tugas aktif' => (int) $pdo->query('SELECT COUNT(*) FROM assignments')->fetchColumn(),
        'Pengumpulan' => (int) $pdo->query('SELECT COUNT(*) FROM submissions')->fetchColumn(),
    ];
    $users = $pdo->query('SELECT u.*, COUNT(DISTINCT s.id) AS submission_count FROM users u LEFT JOIN submissions s ON s.student_id = u.id GROUP BY u.id ORDER BY u.created_at DESC')->fetchAll();
    $teachers = $pdo->query('SELECT id, name FROM users WHERE role = "teacher" ORDER BY name')->fetchAll();
    $courses = $pdo->query('SELECT c.*, u.name AS teacher_name, COUNT(DISTINCT a.id) AS assignment_count FROM courses c JOIN users u ON u.id = c.teacher_id LEFT JOIN assignments a ON a.course_id = c.id GROUP BY c.id ORDER BY c.name')->fetchAll();
    $submissions = $pdo->query('SELECT s.*, a.title AS assignment_title, c.name AS course_name, u.name AS student_name FROM submissions s JOIN assignments a ON a.id = s.assignment_id JOIN courses c ON c.id = a.course_id JOIN users u ON u.id = s.student_id ORDER BY s.submitted_at DESC LIMIT 20')->fetchAll();
} elseif ($role === 'teacher') {
    $courseStatement = $pdo->prepare('SELECT * FROM courses WHERE teacher_id = ? ORDER BY name');
    $courseStatement->execute([$user['id']]);
    $courses = $courseStatement->fetchAll();
    $assignmentStatement = $pdo->prepare(
        'SELECT a.*, c.name AS course_name, c.code AS course_code,
         COUNT(s.id) AS submission_count,
         SUM(CASE WHEN s.score IS NULL THEN 1 ELSE 0 END) AS pending_count
         FROM assignments a JOIN courses c ON c.id = a.course_id
         LEFT JOIN submissions s ON s.assignment_id = a.id
         WHERE c.teacher_id = ? GROUP BY a.id ORDER BY a.created_at DESC'
    );
    $assignmentStatement->execute([$user['id']]);
    $assignments = $assignmentStatement->fetchAll();
    $submissionStatement = $pdo->prepare(
        'SELECT s.*, a.title AS assignment_title, a.due_date, c.name AS course_name, u.name AS student_name
         FROM submissions s JOIN assignments a ON a.id = s.assignment_id JOIN courses c ON c.id = a.course_id JOIN users u ON u.id = s.student_id
         WHERE c.teacher_id = ? ORDER BY (s.score IS NULL) DESC, s.submitted_at DESC'
    );
    $submissionStatement->execute([$user['id']]);
    $submissions = $submissionStatement->fetchAll();
    $overview = [
        'Mata pelajaran' => count($courses),
        'Tugas diterbitkan' => count($assignments),
        'Perlu dinilai' => count(array_filter($submissions, static fn(array $item): bool => $item['score'] === null)),
        'Sudah dikumpulkan' => count($submissions),
    ];
} else {
    $statement = $pdo->prepare(
        'SELECT a.*, c.name AS course_name, c.code AS course_code, u.name AS teacher_name,
         s.id AS submission_id, s.file_original, s.submitted_at, s.score, s.feedback, s.graded_at
         FROM assignments a JOIN courses c ON c.id = a.course_id JOIN users u ON u.id = c.teacher_id
         LEFT JOIN submissions s ON s.assignment_id = a.id AND s.student_id = ?
         ORDER BY (a.due_date IS NULL), a.due_date ASC, a.created_at DESC'
    );
    $statement->execute([$user['id']]);
    $assignments = $statement->fetchAll();
    $overview = [
        'Semua tugas' => count($assignments),
        'Sudah dikumpulkan' => count(array_filter($assignments, static fn(array $item): bool => $item['submission_id'] !== null)),
        'Sudah dinilai' => count(array_filter($assignments, static fn(array $item): bool => $item['score'] !== null)),
        'Rata-rata nilai' => ($graded = array_values(array_filter($assignments, static fn(array $item): bool => $item['score'] !== null))) ? number_format(array_sum(array_map(static fn(array $item): float => (float) $item['score'], $graded)) / count($graded), 1, ',', '.') : '—',
    ];
}

$roleName = role_label($role);
$navItems = match ($role) {
    'admin' => [['overview', 'Ringkasan'], ['users', 'Pengguna'], ['courses', 'Mata pelajaran'], ['admin-submissions', 'Pengumpulan']],
    'teacher' => [['overview', 'Ringkasan'], ['teacher-assignments', 'Tugas'], ['submissions', 'Penilaian']],
    default => [['overview', 'Ringkasan'], ['assignments', 'Daftar tugas'], ['grades', 'Nilai saya']],
};
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#f3f5ef">
    <title><?= e($roleName) ?> | LMS SMAN 1 Parepare</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body class="app-page">
    <div class="app-shell">
        <aside class="sidebar" id="sidebar">
            <a class="sidebar-brand" href="#overview"><span class="brand-mark">L</span><span><strong>SMAN 1</strong><small>PAREPARE · LMS</small></span></a>
            <div class="sidebar-section-label">RUANG KERJA</div>
            <nav class="side-nav" aria-label="Navigasi utama">
                <?php foreach ($navItems as $index => [$anchor, $label]): ?>
                    <a href="#<?= e($anchor) ?>" class="side-link <?= $index === 0 ? 'active' : '' ?>"><span class="nav-dot"></span><?= e($label) ?></a>
                <?php endforeach; ?>
            </nav>
            <div class="sidebar-bottom">
                <div class="sidebar-school"><span class="school-stamp">01</span><span><strong>Bahasa Inggris</strong><small>Tahun ajaran 2026/2027</small></span></div>
                <div class="sidebar-user"><span class="avatar"><?= e(mb_strtoupper(mb_substr($user['name'], 0, 1))) ?></span><span class="user-meta"><strong><?= e($user['name']) ?></strong><small><?= e($roleName) ?></small></span><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="logout"><button class="logout-button" type="submit" title="Keluar" aria-label="Keluar">↗</button></form></div>
            </div>
        </aside>
        <main class="main-area">
            <header class="topbar">
                <button class="menu-toggle" id="menu-toggle" type="button" aria-label="Buka navigasi" aria-expanded="false"><span></span><span></span></button>
                <div class="breadcrumb"><span>Ruang belajar</span><b>/</b><strong><?= e($roleName) ?></strong></div>
                <div class="topbar-date"><span class="date-dot"></span><?= e(today_label()) ?></div>
            </header>
            <div class="content-wrap">
                <?php if ($flash): ?><div class="notice notice-<?= e($flash['type']) ?>" role="status"><?= e($flash['message']) ?></div><?php endif; ?>
                <section class="welcome-row" id="overview">
                    <div><p class="eyebrow">DASHBOARD · <?= e(strtoupper($roleName)) ?></p><h1><?= $role === 'student' ? 'Halo, ' . e($user['name']) . '.' : 'Selamat datang, ' . e($user['name']) . '.' ?></h1><p class="muted welcome-copy"><?= $role === 'admin' ? 'Pantau kegiatan belajar dan kelola data sekolah.' : ($role === 'teacher' ? 'Ruang kelas Anda siap untuk hari ini.' : 'Mari lanjutkan langkah belajarmu hari ini.') ?></p></div>
                    <div class="welcome-index"><span><?= e(date('d')) ?></span><small><?= e(strtoupper(date('M Y'))) ?></small></div>
                </section>
                <section class="stats-grid" aria-label="Ringkasan">
                    <?php $statIndex = 0; foreach ($overview as $label => $value): ?>
                        <article class="stat-item stat-tone-<?= $statIndex + 1 ?>"><div class="stat-top"><span><?= e($label) ?></span><span class="stat-index">0<?= ++$statIndex ?></span></div><strong><?= e($value) ?></strong><div class="stat-bottom"><span class="stat-line"></span><span>SMAN 1 PAREPARE</span></div></article>
                    <?php endforeach; ?>
                </section>

                <?php if ($role === 'admin'): ?>
                    <section class="section-block" id="users">
                        <div class="section-heading"><div><p class="eyebrow">AKSES SEKOLAH</p><h2>Pengguna</h2></div><span class="section-count"><?= count($users) ?> akun</span></div>
                        <div class="workspace-grid">
                            <div class="surface table-surface">
                                <div class="surface-heading"><div><h3>Daftar akun</h3><p>Kelola akses guru dan siswa.</p></div><span class="surface-mark">01</span></div>
                                <div class="table-scroll"><table><thead><tr><th>Nama</th><th>Username</th><th>Peran</th><th>Aktivitas</th><th></th></tr></thead><tbody>
                                <?php foreach ($users as $account): ?><tr><td class="name-cell"><?= e($account['name']) ?></td><td><?= e($account['username']) ?></td><td><span class="role-pill role-<?= e($account['role']) ?>"><?= e(role_label($account['role'])) ?></span></td><td><?= (int) $account['submission_count'] ?> pengumpulan</td><td><?php if ($account['role'] !== 'admin'): ?><form method="post" data-confirm="Hapus akun <?= e($account['name']) ?>?"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete_user"><input type="hidden" name="user_id" value="<?= (int) $account['id'] ?>"><button class="icon-action" type="submit" title="Hapus akun" aria-label="Hapus akun">×</button></form><?php else: ?><span class="muted">—</span><?php endif; ?></td></tr><?php endforeach; ?>
                                <?php if (!$users): ?><tr><td colspan="5" class="empty-cell">Belum ada akun.</td></tr><?php endif; ?>
                                </tbody></table></div>
                            </div>
                            <div class="surface form-surface"><div class="surface-heading"><div><h3>Tambah pengguna</h3><p>Buat akses guru atau siswa.</p></div><span class="surface-mark">+</span></div>
                                <form method="post" class="form-stack compact-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="create_user"><label for="new-name">Nama lengkap</label><input id="new-name" name="name" maxlength="120" placeholder="Nama pengguna" required><label for="new-username">Username</label><input id="new-username" name="username" minlength="3" maxlength="60" pattern="[A-Za-z0-9._-]+" placeholder="Contoh: guru.bahasa" required><label for="new-password">Password</label><input id="new-password" name="password" type="password" minlength="4" placeholder="Minimal 4 karakter" required><label for="new-role">Peran</label><select id="new-role" name="role" required><option value="teacher">Guru</option><option value="student">Siswa</option></select><button class="button button-dark" type="submit">Buat akun <span aria-hidden="true">↗</span></button></form>
                            </div>
                        </div>
                    </section>
                    <section class="section-block" id="courses">
                        <div class="section-heading"><div><p class="eyebrow">KURIKULUM</p><h2>Mata pelajaran</h2></div><span class="section-count"><?= count($courses) ?> kelas</span></div>
                        <div class="workspace-grid">
                            <div class="surface table-surface"><div class="surface-heading"><div><h3>Daftar mata pelajaran</h3><p>Guru pengampu dan jumlah tugas.</p></div><span class="surface-mark">02</span></div><div class="table-scroll"><table><thead><tr><th>Kode</th><th>Mata pelajaran</th><th>Guru</th><th>Tugas</th></tr></thead><tbody><?php foreach ($courses as $course): ?><tr><td><span class="course-code"><?= e($course['code']) ?></span></td><td class="name-cell"><?= e($course['name']) ?></td><td><?= e($course['teacher_name']) ?></td><td><?= (int) $course['assignment_count'] ?></td></tr><?php endforeach; ?><?php if (!$courses): ?><tr><td colspan="4" class="empty-cell">Belum ada mata pelajaran.</td></tr><?php endif; ?></tbody></table></div></div>
                            <div class="surface form-surface"><div class="surface-heading"><div><h3>Tambah mata pelajaran</h3><p>Tetapkan guru pengampu.</p></div><span class="surface-mark">+</span></div><form method="post" class="form-stack compact-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="create_course"><label for="course-name">Nama mata pelajaran</label><input id="course-name" name="name" maxlength="140" placeholder="Bahasa Inggris" required><label for="course-code">Kode kelas</label><input id="course-code" name="code" maxlength="30" placeholder="BING-X-RPL1" required><label for="course-teacher">Guru pengampu</label><select id="course-teacher" name="teacher_id" required><option value="">Pilih guru</option><?php foreach ($teachers as $teacher): ?><option value="<?= (int) $teacher['id'] ?>"><?= e($teacher['name']) ?></option><?php endforeach; ?></select><?php if (!$teachers): ?><p class="form-hint">Buat akun guru terlebih dahulu.</p><?php endif; ?><button class="button button-dark" type="submit" <?= !$teachers ? 'disabled' : '' ?>>Simpan mata pelajaran <span aria-hidden="true">↗</span></button></form></div>
                        </div>
                    </section>
                    <section class="section-block" id="admin-submissions"><div class="section-heading"><div><p class="eyebrow">AKTIVITAS TERBARU</p><h2>Pengumpulan siswa</h2></div><span class="section-count">20 terbaru</span></div><div class="surface table-surface"><div class="table-scroll"><table><thead><tr><th>Siswa</th><th>Tugas</th><th>Kelas</th><th>Waktu kumpul</th><th>Nilai</th><th>Berkas</th></tr></thead><tbody><?php foreach ($submissions as $submission): ?><tr><td class="name-cell"><?= e($submission['student_name']) ?></td><td><?= e($submission['assignment_title']) ?></td><td><?= e($submission['course_name']) ?></td><td><?= e(date_label($submission['submitted_at'])) ?></td><td><?= $submission['score'] === null ? '<span class="status-pending">Belum dinilai</span>' : '<strong>' . e(number_format((float) $submission['score'], 1, ',', '.')) . '</strong>' ?></td><td><a class="text-link" href="?download=<?= (int) $submission['id'] ?>">Unduh ↗</a></td></tr><?php endforeach; ?><?php if (!$submissions): ?><tr><td colspan="6" class="empty-cell">Belum ada pengumpulan tugas.</td></tr><?php endif; ?></tbody></table></div></div></section>
                <?php elseif ($role === 'teacher'): ?>
                    <section class="section-block" id="teacher-assignments">
                        <div class="section-heading"><div><p class="eyebrow">RUANG KELAS</p><h2>Tugas dan materi</h2></div><a class="button button-outline" href="#create-task">Buat tugas <span aria-hidden="true">＋</span></a></div>
                        <div class="workspace-grid teacher-grid">
                            <div class="surface table-surface"><div class="surface-heading"><div><h3>Tugas diterbitkan</h3><p>Ringkasan pengumpulan setiap tugas.</p></div><span class="surface-mark">01</span></div><div class="table-scroll"><table><thead><tr><th>Tugas</th><th>Kelas</th><th>Tenggat</th><th>Pengumpulan</th><th>Perlu dinilai</th></tr></thead><tbody><?php foreach ($assignments as $assignment): ?><tr><td class="name-cell"><?= e($assignment['title']) ?></td><td><span class="course-code"><?= e($assignment['course_code']) ?></span></td><td><?= e(date_label($assignment['due_date'])) ?></td><td><?= (int) $assignment['submission_count'] ?></td><td><?= (int) $assignment['pending_count'] ?></td></tr><?php endforeach; ?><?php if (!$assignments): ?><tr><td colspan="5" class="empty-cell">Belum ada tugas. Buat tugas pertama di panel sebelah.</td></tr><?php endif; ?></tbody></table></div></div>
                            <div class="surface form-surface" id="create-task"><div class="surface-heading"><div><h3>Terbitkan tugas</h3><p>Bagikan instruksi ke siswa.</p></div><span class="surface-mark">＋</span></div><?php if ($courses): ?><form method="post" class="form-stack compact-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="create_assignment"><label for="task-course">Mata pelajaran</label><select id="task-course" name="course_id" required><?php foreach ($courses as $course): ?><option value="<?= (int) $course['id'] ?>"><?= e($course['code'] . ' · ' . $course['name']) ?></option><?php endforeach; ?></select><label for="task-title">Judul tugas</label><input id="task-title" name="title" maxlength="180" placeholder="Contoh: My Future Career" required><label for="task-description">Instruksi</label><textarea id="task-description" name="description" rows="4" placeholder="Tuliskan instruksi dan kriteria tugas..." required></textarea><label for="task-due">Tenggat pengumpulan</label><input id="task-due" name="due_date" type="datetime-local"><button class="button button-dark" type="submit">Terbitkan tugas <span aria-hidden="true">↗</span></button></form><?php else: ?><div class="empty-state"><span class="empty-symbol">01</span><p>Belum ada mata pelajaran yang ditetapkan untuk Anda.</p><small>Hubungi admin untuk menambahkan kelas pengampu.</small></div><?php endif; ?></div>
                        </div>
                    </section>
                    <section class="section-block" id="submissions"><div class="section-heading"><div><p class="eyebrow">KOREKSI & UMPAN BALIK</p><h2>Penilaian siswa</h2></div><span class="section-count"><?= count($submissions) ?> berkas</span></div><div class="grading-list">
                        <?php foreach ($submissions as $submission): ?><article class="surface grading-item"><div class="grading-student"><span class="avatar avatar-small"><?= e(mb_strtoupper(mb_substr($submission['student_name'], 0, 1))) ?></span><div><strong><?= e($submission['student_name']) ?></strong><small><?= e($submission['course_name']) ?> · <?= e($submission['assignment_title']) ?></small></div></div><div class="grading-file"><span class="file-chip">FILE</span><span><strong><?= e($submission['file_original']) ?></strong><small>Dikumpulkan <?= e(date_label($submission['submitted_at'])) ?></small></span><a class="download-link" href="?download=<?= (int) $submission['id'] ?>" aria-label="Unduh <?= e($submission['file_original']) ?>" title="Unduh berkas">↓</a></div><form method="post" class="grade-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="grade_submission"><input type="hidden" name="submission_id" value="<?= (int) $submission['id'] ?>"><div class="grade-score"><label for="score-<?= (int) $submission['id'] ?>">Nilai</label><div class="score-input"><input id="score-<?= (int) $submission['id'] ?>" name="score" type="number" min="0" max="100" step="0.01" value="<?= $submission['score'] === null ? '' : e($submission['score']) ?>" placeholder="0-100" required><span>/ 100</span></div></div><div class="grade-feedback"><label for="feedback-<?= (int) $submission['id'] ?>">Umpan balik</label><input id="feedback-<?= (int) $submission['id'] ?>" name="feedback" maxlength="2000" value="<?= e($submission['feedback'] ?? '') ?>" placeholder="Catatan untuk siswa"></div><button class="button button-dark grade-button" type="submit"><?= $submission['score'] === null ? 'Simpan nilai' : 'Perbarui nilai' ?> <span aria-hidden="true">↗</span></button></form></article><?php endforeach; ?>
                        <?php if (!$submissions): ?><div class="surface empty-state"><span class="empty-symbol">—</span><p>Belum ada tugas yang dikumpulkan.</p><small>Pengumpulan siswa akan muncul di sini.</small></div><?php endif; ?>
                    </div></section>
                <?php else: ?>
                    <section class="section-block" id="assignments"><div class="section-heading"><div><p class="eyebrow">BELAJAR & KUMPULKAN</p><h2>Daftar tugas</h2></div><span class="section-count"><?= count($assignments) ?> tugas</span></div><div class="assignment-list">
                        <?php foreach ($assignments as $assignment): ?><article class="surface assignment-item"><div class="assignment-main"><div class="assignment-code"><?= e($assignment['course_code']) ?></div><div class="assignment-copy"><div class="assignment-meta"><span><?= e($assignment['course_name']) ?></span><span class="meta-separator">·</span><span>Guru <?= e($assignment['teacher_name']) ?></span></div><h3><?= e($assignment['title']) ?></h3><p><?= nl2br(e($assignment['description'])) ?></p><div class="assignment-due"><span class="due-dot <?= $assignment['due_date'] && strtotime($assignment['due_date']) < time() ? 'due-late' : '' ?>"></span>Batas pengumpulan: <?= e(date_label($assignment['due_date'])) ?></div></div></div><div class="assignment-submit">
                            <?php if ($assignment['submission_id']): ?><div class="submitted-file"><span class="file-chip">FILE</span><span><strong><?= e($assignment['file_original']) ?></strong><small>Dikirim <?= e(date_label($assignment['submitted_at'])) ?></small></span><a class="download-link" href="?download=<?= (int) $assignment['submission_id'] ?>" title="Unduh berkas sendiri" aria-label="Unduh berkas sendiri">↓</a></div><?php endif; ?>
                            <?php if ($assignment['score'] !== null): ?><div class="student-grade"><span>Nilai akhir</span><strong><?= e(number_format((float) $assignment['score'], 1, ',', '.')) ?><small> / 100</small></strong></div><?php elseif ($assignment['submission_id']): ?><div class="grade-pending"><span class="status-pending">Menunggu penilaian</span></div><?php endif; ?>
                            <form method="post" enctype="multipart/form-data" class="upload-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="submit_assignment"><input type="hidden" name="assignment_id" value="<?= (int) $assignment['id'] ?>"><label class="upload-control"><input type="file" name="submission_file" accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.jpg,.jpeg,.png" required><span><?= $assignment['submission_id'] ? 'Ganti berkas' : 'Pilih berkas' ?></span></label><button class="button button-dark" type="submit"><?= $assignment['submission_id'] ? 'Kumpulkan ulang' : 'Kumpulkan tugas' ?> <span aria-hidden="true">↗</span></button><small>PDF, Office, JPG, PNG · Maks. 10 MB</small></form>
                            <?php if ($assignment['score'] !== null && trim((string) $assignment['feedback']) !== ''): ?><div class="feedback-note"><span>CATATAN GURU</span><p><?= nl2br(e($assignment['feedback'])) ?></p></div><?php endif; ?>
                        </div></article><?php endforeach; ?>
                        <?php if (!$assignments): ?><div class="surface empty-state"><span class="empty-symbol">—</span><p>Belum ada tugas untuk kelas Anda.</p><small>Tugas yang diterbitkan guru akan muncul di sini.</small></div><?php endif; ?>
                    </div></section>
                    <section class="section-block grade-history" id="grades"><div class="section-heading"><div><p class="eyebrow">HASIL BELAJAR</p><h2>Nilai saya</h2></div><span class="section-count"><?= (int) $overview['Sudah dinilai'] ?> penilaian</span></div><div class="surface table-surface"><div class="table-scroll"><table><thead><tr><th>Tugas</th><th>Mata pelajaran</th><th>Tanggal dinilai</th><th>Nilai</th><th>Umpan balik</th></tr></thead><tbody><?php $gradedAssignments = array_values(array_filter($assignments, static fn(array $item): bool => $item['score'] !== null)); foreach ($gradedAssignments as $item): ?><tr><td class="name-cell"><?= e($item['title']) ?></td><td><?= e($item['course_name']) ?></td><td><?= e(date_label($item['graded_at'])) ?></td><td><span class="score-badge"><?= e(number_format((float) $item['score'], 1, ',', '.')) ?></span></td><td><?= trim((string) $item['feedback']) !== '' ? e($item['feedback']) : '<span class="muted">—</span>' ?></td></tr><?php endforeach; ?><?php if (!$gradedAssignments): ?><tr><td colspan="5" class="empty-cell">Nilai yang sudah diberikan guru akan tampil di sini.</td></tr><?php endif; ?></tbody></table></div></div></section>
                <?php endif; ?>
                <footer class="app-footer"><span>SMAN 1 PAREPARE</span><span>Learning Management System <b>·</b> <?= e(date('Y')) ?></span></footer>
            </div>
        </main>
    </div>
    <div class="sidebar-scrim" id="sidebar-scrim"></div>
    <script src="assets/app.js" defer></script>
</body>
</html>