<?php
declare(strict_types=1);

function table_exists(PDO $pdo, string $table): bool
{
    $statement = $pdo->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?');
    $statement->execute([$table]);
    return (int) $statement->fetchColumn() > 0;
}

function column_exists(PDO $pdo, string $table, string $column): bool
{
    $statement = $pdo->prepare('SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?');
    $statement->execute([$table, $column]);
    return (int) $statement->fetchColumn() > 0;
}

function preserve_legacy_tables(PDO $pdo): bool
{
    $hasArchivedCourses = table_exists($pdo, 'legacy_courses');
    $hasArchivedAssignments = table_exists($pdo, 'legacy_assignments');
    if ($hasArchivedCourses || $hasArchivedAssignments) {
        $newAssignments = table_exists($pdo, 'assignments') && column_exists($pdo, 'assignments', 'teacher_assignment_id');
        if (!$hasArchivedCourses || !$hasArchivedAssignments || table_exists($pdo, 'courses') || !$newAssignments) {
            throw new RuntimeException('Struktur arsip migrasi tidak lengkap. Pulihkan cadangan database sebelum melanjutkan.');
        }
        return true;
    }

    $isLegacy = table_exists($pdo, 'courses')
        && column_exists($pdo, 'courses', 'teacher_id')
        && table_exists($pdo, 'assignments')
        && column_exists($pdo, 'assignments', 'course_id');

    if (!$isLegacy) {
        return false;
    }

    $tables = ['courses' => 'legacy_courses', 'assignments' => 'legacy_assignments'];
    if (table_exists($pdo, 'submissions')) {
        $tables['submissions'] = 'legacy_submissions';
    }
    $renames = [];
    foreach ($tables as $old => $new) {
        $renames[] = "`{$old}` TO `{$new}`";
    }
    $pdo->exec('RENAME TABLE ' . implode(', ', $renames));
    return true;
}

function import_legacy_data(PDO $pdo, bool $hasLegacy): void
{
    if (!$hasLegacy || !table_exists($pdo, 'legacy_courses')) {
        return;
    }

    $pdo->beginTransaction();
    try {
        $students = $pdo->query('SELECT id FROM users WHERE role = "student"')->fetchAll(PDO::FETCH_COLUMN);
        $courseMap = [];
        $legacyCourses = $pdo->query('SELECT * FROM legacy_courses ORDER BY id')->fetchAll();

        foreach ($legacyCourses as $legacyCourse) {
            $assignment = $pdo->prepare('SELECT id, class_id FROM teacher_assignments WHERE legacy_course_id = ?');
            $assignment->execute([$legacyCourse['id']]);
            $mapped = $assignment->fetch();
            if (!$mapped) {
                $classInsert = $pdo->prepare('INSERT INTO classes (name, code, academic_year) VALUES (?, ?, ?)');
                $classInsert->execute(['Rombel ' . $legacyCourse['code'], 'LEG-' . $legacyCourse['id'], '2026/2027']);
                $classId = (int) $pdo->lastInsertId();

                $subjectInsert = $pdo->prepare('INSERT INTO subjects (name, code) VALUES (?, ?)');
                $subjectInsert->execute([$legacyCourse['name'], 'LEG-' . $legacyCourse['id']]);
                $subjectId = (int) $pdo->lastInsertId();

                $teacherInsert = $pdo->prepare('INSERT INTO teacher_assignments (teacher_id, class_id, subject_id, legacy_course_id) VALUES (?, ?, ?, ?)');
                $teacherInsert->execute([$legacyCourse['teacher_id'], $classId, $subjectId, $legacyCourse['id']]);
                $teacherAssignmentId = (int) $pdo->lastInsertId();

                $enrollment = $pdo->prepare('INSERT IGNORE INTO class_students (class_id, student_id) VALUES (?, ?)');
                foreach ($students as $studentId) {
                    $enrollment->execute([$classId, $studentId]);
                }
            } else {
                $classId = (int) $mapped['class_id'];
                $teacherAssignmentId = (int) $mapped['id'];
            }
            $courseMap[(int) $legacyCourse['id']] = ['teacher_assignment_id' => $teacherAssignmentId, 'class_id' => $classId];
        }

        if (table_exists($pdo, 'legacy_assignments')) {
            $legacyAssignments = $pdo->query('SELECT * FROM legacy_assignments ORDER BY id')->fetchAll();
            $insert = $pdo->prepare(
                'INSERT INTO assignments (teacher_assignment_id, title, description, due_at, created_by, legacy_assignment_id, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?)'
            );
            foreach ($legacyAssignments as $item) {
                if (!isset($courseMap[(int) $item['course_id']])) {
                    continue;
                }
                $exists = $pdo->prepare('SELECT id FROM assignments WHERE legacy_assignment_id = ?');
                $exists->execute([$item['id']]);
                if ($exists->fetchColumn()) {
                    continue;
                }
                $teacherQuery = $pdo->prepare('SELECT teacher_id FROM teacher_assignments WHERE id = ?');
                $teacherQuery->execute([$courseMap[(int) $item['course_id']]['teacher_assignment_id']]);
                $insert->execute([
                    $courseMap[(int) $item['course_id']]['teacher_assignment_id'],
                    $item['title'],
                    $item['description'],
                    $item['due_date'],
                    $teacherQuery->fetchColumn(),
                    $item['id'],
                    $item['created_at'],
                ]);
            }
        }

        if (table_exists($pdo, 'legacy_submissions')) {
            $legacySubmissions = $pdo->query(
                'SELECT s.*, a.id AS old_assignment_id FROM legacy_submissions s
                 JOIN legacy_assignments a ON a.id = s.assignment_id ORDER BY s.id'
            )->fetchAll();
            foreach ($legacySubmissions as $item) {
                $assignmentQuery = $pdo->prepare('SELECT id FROM assignments WHERE legacy_assignment_id = ?');
                $assignmentQuery->execute([$item['old_assignment_id']]);
                $newAssignmentId = $assignmentQuery->fetchColumn();
                if (!$newAssignmentId) {
                    continue;
                }
                $exists = $pdo->prepare('SELECT id FROM submissions WHERE legacy_submission_id = ?');
                $exists->execute([$item['id']]);
                if ($exists->fetchColumn()) {
                    continue;
                }
                $insert = $pdo->prepare(
                    'INSERT INTO submissions (assignment_id, student_id, file_original, file_stored, submitted_at, legacy_submission_id, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?)'
                );
                $insert->execute([$newAssignmentId, $item['student_id'], $item['file_original'], $item['file_stored'], $item['submitted_at'], $item['id'], $item['submitted_at']]);
                $submissionId = (int) $pdo->lastInsertId();
                $version = $pdo->prepare('INSERT INTO submission_versions (submission_id, revision_number, file_original, file_stored, submitted_at, uploaded_by) VALUES (?, 1, ?, ?, ?, ?)');
                $version->execute([$submissionId, $item['file_original'], $item['file_stored'], $item['submitted_at'], $item['student_id']]);

                if ($item['score'] !== null) {
                    $graderId = $item['graded_by'] ?: (int) $pdo->query('SELECT id FROM users WHERE role = "admin" ORDER BY id LIMIT 1')->fetchColumn();
                    if ($graderId > 0) {
                        $grade = $pdo->prepare('INSERT INTO grades (submission_id, score, feedback, graded_by, graded_at) VALUES (?, ?, ?, ?, ?)');
                        $grade->execute([$submissionId, $item['score'], $item['feedback'], $graderId, $item['graded_at'] ?: $item['submitted_at']]);
                        $gradeId = (int) $pdo->lastInsertId();
                        $history = $pdo->prepare('INSERT INTO grade_history (grade_id, score, feedback, is_published, changed_by, changed_at) VALUES (?, ?, ?, 1, ?, ?)');
                        $history->execute([$gradeId, $item['score'], $item['feedback'], $graderId, $item['graded_at'] ?: $item['submitted_at']]);
                    }
                }
            }
        }

        $pdo->commit();
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $exception;
    }
}