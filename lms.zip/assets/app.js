document.addEventListener('DOMContentLoaded', () => {
    const menuButton = document.querySelector('#menu-toggle');
    const sidebar = document.querySelector('#sidebar');
    const scrim = document.querySelector('#sidebar-scrim');

    const setMenu = (open) => {
        sidebar?.classList.toggle('is-open', open);
        scrim?.classList.toggle('is-visible', open);
        menuButton?.setAttribute('aria-expanded', String(open));
    };

    menuButton?.addEventListener('click', () => {
        setMenu(!sidebar?.classList.contains('is-open'));
    });
    scrim?.addEventListener('click', () => setMenu(false));
    sidebar?.querySelectorAll('a').forEach((link) => {
        link.addEventListener('click', () => setMenu(false));
    });

    document.querySelectorAll('.password-toggle').forEach((button) => {
        button.addEventListener('click', () => {
            const input = button.parentElement?.querySelector('input');
            if (!input) return;
            const visible = input.type === 'password';
            input.type = visible ? 'text' : 'password';
            button.textContent = visible ? 'Sembunyikan' : 'Lihat';
            button.setAttribute('aria-label', visible ? 'Sembunyikan password' : 'Tampilkan password');
        });
    });

    document.querySelectorAll('.upload-control input[type="file"]').forEach((input) => {
        input.addEventListener('change', () => {
            const label = input.parentElement?.querySelector('span');
            const fileName = input.files?.[0]?.name;
            if (label && fileName) label.textContent = fileName;
        });
    });

    document.querySelectorAll('form[data-confirm]').forEach((form) => {
        form.addEventListener('submit', (event) => {
            if (!window.confirm(form.getAttribute('data-confirm') || 'Lanjutkan tindakan ini?')) {
                event.preventDefault();
            }
        });
    });

    document.querySelectorAll('.table-toolbar, .standalone-toolbar').forEach((toolbar) => {
        const section = toolbar.closest('.section-block');
        const search = toolbar.querySelector('[data-table-filter]');
        const status = toolbar.querySelector('[data-status-filter]');
        if (!section) return;

        const updateRows = () => {
            const query = search?.value.trim().toLocaleLowerCase('id') || '';
            const selectedStatus = status?.value || '';
            section.querySelectorAll('tbody tr, .assignment-item[data-status]').forEach((row) => {
                const matchesText = row.textContent.toLocaleLowerCase('id').includes(query);
                const matchesStatus = !selectedStatus || row.dataset.status === selectedStatus || (selectedStatus === 'Sudah dinilai' && row.dataset.status.startsWith('Sudah dinilai'));
                row.hidden = !(matchesText && matchesStatus);
            });
        };

        search?.addEventListener('input', updateRows);
        status?.addEventListener('change', updateRows);
    });

    const sections = [...document.querySelectorAll('.content-wrap section[id]')];
    const navLinks = [...document.querySelectorAll('.side-link')];
    if ('IntersectionObserver' in window && sections.length && navLinks.length) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (!entry.isIntersecting) return;
                navLinks.forEach((link) => {
                    link.classList.toggle('active', link.getAttribute('href') === `#${entry.target.id}`);
                });
            });
        }, { rootMargin: '-25% 0px -65% 0px' });
        sections.forEach((section) => observer.observe(section));
    }
});