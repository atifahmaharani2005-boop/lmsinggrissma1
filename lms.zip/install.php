<?php
declare(strict_types=1);

require __DIR__ . '/config.php';
require __DIR__ . '/migrate.php';

$host = getenv('DB_HOST') ?: '127.0.0.1';
$name = getenv('DB_NAME') ?: 'lms_smkn1_parepare';
$user = getenv('DB_USER') ?: 'root';
$pass = getenv('DB_PASS') ?: '';
$error = '';
$installed = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    try {
        $server = new PDO("mysql:host={$host};charset=utf8mb4", $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        $server->exec("CREATE DATABASE IF NOT EXISTS `{$name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $connection = new PDO("mysql:host={$host};dbname={$name};charset=utf8mb4", $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);

        $hasLegacy = preserve_legacy_tables($connection);
        if (table_exists($connection, 'users') && !column_exists($connection, 'users', 'updated_at')) {
            $connection->exec('ALTER TABLE users ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP');
        }
        $schema = file_get_contents(__DIR__ . '/database.sql');
        foreach (array_filter(array_map('trim', explode(';', (string) $schema))) as $statement) {
            $connection->exec($statement);
        }
        import_legacy_data($connection, $hasLegacy);

        $insert = $connection->prepare('INSERT INTO users (name, username, password_hash, role) VALUES (?, ?, ?, ?)');
        $lookup = $connection->prepare('SELECT id FROM users WHERE username = ?');
        foreach ([
            ['Administrator LMS', 'admin', 'admin', 'admin'],
            ['Guru Bahasa Inggris', 'guru', 'guru', 'teacher'],
            ['Siswa SMAN 1 Parepare', 'siswa', 'siswa', 'student'],
        ] as [$person, $username, $password, $role]) {
            $lookup->execute([$username]);
            if (!$lookup->fetchColumn()) {
                $insert->execute([$person, $username, password_hash($password, PASSWORD_DEFAULT), $role]);
            }
        }
        $connection->prepare('UPDATE users SET name = ? WHERE username = ? AND name LIKE ?')->execute(['Siswa SMAN 1 Parepare', 'siswa', 'Siswa SM_N 1 Parepare']);

        $teacherId = $connection->query('SELECT id FROM users WHERE username = "guru" AND role = "teacher" LIMIT 1')->fetchColumn();
        $classCount = (int) $connection->query('SELECT COUNT(*) FROM classes')->fetchColumn();
        if ($teacherId && $classCount === 0) {
            $connection->beginTransaction();
            $connection->prepare('INSERT INTO classes (name, code, academic_year) VALUES (?, ?, ?)')->execute(['X RPL 1', 'X-RPL-1', '2026/2027']);
            $classId = (int) $connection->lastInsertId();
            $connection->prepare('INSERT INTO subjects (name, code) VALUES (?, ?)')->execute(['Bahasa Inggris', 'BING']);
            $subjectId = (int) $connection->lastInsertId();
            $connection->prepare('INSERT INTO teacher_assignments (teacher_id, class_id, subject_id) VALUES (?, ?, ?)')->execute([$teacherId, $classId, $subjectId]);
            $studentId = $connection->query('SELECT id FROM users WHERE username = "siswa" AND role = "student" LIMIT 1')->fetchColumn();
            if ($studentId) {
                $connection->prepare('INSERT INTO class_students (class_id, student_id) VALUES (?, ?)')->execute([$classId, $studentId]);
            }
            $connection->commit();
        }

        if (!is_dir(__DIR__ . '/storage/uploads')) {
            mkdir(__DIR__ . '/storage/uploads', 0750, true);
        }
        $installed = true;
    } catch (Throwable $exception) {
        error_log('LMS installer error: ' . $exception->getMessage());
        $error = 'Instalasi gagal. Periksa konfigurasi database dan log PHP, lalu coba lagi.';
    }
}
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Instalasi LMS | SMAN 1 Parepare</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body class="install-page">
    <main class="install-card">
        <div class="brand-mark">L</div>
        <p class="eyebrow">SMAN 1 PAREPARE · LMS</p>
        <h1>Siapkan ruang belajar.</h1>
        <?php if ($installed): ?>
            <div class="notice notice-success">Database dan akun demo berhasil disiapkan.</div>
            <p class="muted">Akun masuk: <strong>admin / admin</strong>, <strong>guru / guru</strong>, dan <strong>siswa / siswa</strong>. Ganti password demo sebelum aplikasi digunakan sungguhan.</p>
            <a class="button button-primary button-wide" href="index.php">Buka LMS <span aria-hidden="true">↗</span></a>
        <?php else: ?>
            <p class="muted">Installer akan menyiapkan database dan akun demo. Pengaturan bawaan cocok untuk XAMPP.</p>
            <?php if ($error !== ''): ?><div class="notice notice-error"><?= e($error) ?></div><?php endif; ?>
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <button class="button button-primary button-wide" type="submit">Buat database dan akun <span aria-hidden="true">↗</span></button>
            </form>
        <?php endif; ?>
        <p class="install-foot">PHP 8+ · MySQL/MariaDB · PDO MySQL</p>
    </main>
</body>
</html>