# LMS English · SMAN 1 Parepare

Aplikasi pembelajaran Bahasa Inggris berbasis PHP 8+, PDO, MySQL/MariaDB, HTML, CSS, dan JavaScript vanilla untuk admin, guru, dan siswa.

## Menjalankan di XAMPP

1. Pastikan Apache dan MySQL aktif.
2. Letakkan folder proyek di `C:\xampp\htdocs\lms_bahasa_inggris_sma_1`.
3. Buka `http://localhost/lms_bahasa_inggris_sma_1/install.php`, lalu pilih **Buat database dan akun**.
4. Buka `http://localhost/lms_bahasa_inggris_sma_1/` dan masuk dengan salah satu akun:

Untuk menguji dari HP Android/iOS, hubungkan HP dan komputer ke Wi-Fi yang sama, lalu buka `http://192.168.1.7/lms_bahasa_inggris_sma_1/` (ganti alamat IP jika IP Wi-Fi komputer berubah). Jika Windows Firewall meminta izin, izinkan Apache hanya pada **Private network**. Jangan membuat port-forward ke internet untuk akun demo.

| Peran | Username | Password |
| --- | --- | --- |
| Admin | `admin` | `admin` |
| Guru | `guru` | `guru` |
| Siswa | `siswa` | `siswa` |

Pada request `localhost`/IP privat, aplikasi memakai MySQL XAMPP lokal (`lms_smkn1_parepare`, user `root`). Untuk hosting publik, konfigurasi wajib disediakan lewat environment `DB_HOST`, `DB_NAME`, `DB_USER`, dan `DB_PASS`; kredensial tidak disimpan di source code. Untuk XAMPP dengan akun `root` tanpa password pada Windows, set `DB_PASS_EMPTY=1` bila perlu.

Installer aman dijalankan ulang. Jika menemukan skema aplikasi versi lama, tabel lama dipertahankan dengan prefiks `legacy_` dan data tugas, pengumpulan, serta nilai dimigrasikan ke relasi kelas/mapel baru. Akun demo yang sudah ada tidak direset. Untuk database kosong, skema dapat diimpor melalui phpMyAdmin dari `database.sql`; untuk database lama, jalankan installer agar migrasi data ikut dilakukan.

Ganti semua password demo sebelum aplikasi dipakai sungguhan. Password demo pendek hanya untuk pengujian lokal.

## Alur aplikasi

- Admin mengelola akun, kelas/rombel, anggota kelas, mata pelajaran, dan penugasan guru-kelas-mapel. Data yang masih memiliki aktivitas belajar tidak dapat dihapus tanpa melepas relasinya.
- Untuk satu siswa, admin membuka **Siswa kelas** lalu mengisi nama lengkap, username alfabetis, password minimal 8 karakter, dan kelas tujuan. Akun dibuat sebagai `student`, password di-hash, dan keanggotaan kelas disimpan dalam satu transaksi.
- Admin dapat menambah siswa sekaligus melalui menu **Siswa kelas**. Setiap baris berformat `NAMA LENGKAP | PASSWORD 10 DIGIT`; username dibuat dari nama dengan menghapus spasi/tanda baca dan mengubahnya menjadi huruf kecil. Akun dibuat sebagai role `student` dan hanya dienrol ke kelas yang dipilih.
- Username batch dibuat deterministik. Pastikan hasil nama unik; batch dibatalkan bila username sudah dipakai akun lain. Akun siswa yang sudah ada tidak direset.
- Guru mengunggah materi lewat file atau tautan, membuat/mengubah/menutup tugas, menetapkan tenggat dan kebijakan terlambat/revisi, mengunduh jawaban, serta memberi nilai 0-100 dan umpan balik.
- Sistem mencatat waktu pengumpulan dengan waktu database WITA. Status terlambat dihitung dari `submitted_at > due_at`; revisi tersimpan sebagai versi, dan perubahan nilai memiliki riwayat.
- Siswa hanya melihat materi, tugas, berkas, dan nilai dari kelasnya. Setelah nilai dipublikasikan, siswa dapat melihat nilai dan komentar guru.
- Berkas yang diterima: PDF, Word, Excel, PowerPoint, JPG, dan PNG dengan ukuran maksimal 10 MB.

Semua password disimpan menggunakan `password_hash()` dan diverifikasi dengan `password_verify()`. Username/password siswa yang diberikan saat impor batch hanya untuk pengujian awal; berikan password pribadi yang kuat sebelum akun digunakan untuk pembelajaran sungguhan. Untuk produksi, gunakan kredensial database khusus, aktifkan HTTPS, batasi akses installer setelah setup, dan lindungi/backup folder `storage/uploads`.