<?php
declare(strict_types=1);

require __DIR__ . '/config.php';

function lms_date(?string $date): string
{
    if (!$date) {
        return 'Tidak ditentukan';
    }
    $time = strtotime($date);
    if (!$time) {
        return 'Tidak ditentukan';
    }
    $months = [1 => 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    return date('d', $time) . ' ' . $months[(int) date('n', $time)] . ' ' . date('Y, H:i', $time) . ' WITA';
}

function lms_status(?string $submittedAt, ?string $dueAt, bool $graded): string
{
    if (!$submittedAt) {
        return 'Belum mengumpulkan';
    }
    $late = $dueAt && strtotime($submittedAt) > strtotime($dueAt);
    if ($graded) {
        return $late ? 'Sudah dinilai — terlambat' : 'Sudah dinilai';
    }
    if ($late) {
        return 'Terlambat';
    }
    return 'Sudah mengumpulkan — tepat waktu';
}

function lms_status_class(string $status): string
{
    return match ($status) {
        'Sudah dinilai — terlambat' => 'status-late',
        'Sudah dinilai' => 'status-graded',
        'Terlambat' => 'status-late',
        'Sudah mengumpulkan — tepat waktu' => 'status-on-time',
        default => 'status-not-submitted',
    };
}

function lms_upload(?array $upload, bool $required = true): ?array
{
    if (!$upload || ($upload['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        if ($required) {
            throw new RuntimeException('Pilih berkas terlebih dahulu.');
        }
        return null;
    }
    if (($upload['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK || (int) $upload['size'] <= 0 || (int) $upload['size'] > 10 * 1024 * 1024) {
        throw new RuntimeException('Berkas tidak valid atau melebihi batas 10 MB.');
    }
    $original = basename(str_replace('\\', '/', (string) $upload['name']));
    $extension = strtolower(pathinfo($original, PATHINFO_EXTENSION));
    $mimeByExtension = [
        'pdf' => ['application/pdf'],
        'doc' => ['application/msword', 'application/vnd.ms-office', 'application/octet-stream'],
        'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip', 'application/octet-stream'],
        'xls' => ['application/vnd.ms-excel', 'application/octet-stream'],
        'xlsx' => ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip', 'application/octet-stream'],
        'ppt' => ['application/vnd.ms-powerpoint', 'application/octet-stream'],
        'pptx' => ['application/vnd.openxmlformats-officedocument.presentationml.presentation', 'application/zip', 'application/octet-stream'],
        'jpg' => ['image/jpeg'],
        'jpeg' => ['image/jpeg'],
        'png' => ['image/png'],
    ];
    if (!isset($mimeByExtension[$extension]) || !is_uploaded_file((string) $upload['tmp_name'])) {
        throw new RuntimeException('Format berkas tidak didukung. Gunakan PDF, Word, Excel, PowerPoint, JPG, atau PNG.');
    }
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file((string) $upload['tmp_name']);
    if (!$mime || !in_array($mime, $mimeByExtension[$extension], true)) {
        throw new RuntimeException('Isi berkas tidak sesuai dengan ekstensi yang dipilih.');
    }
    $stored = bin2hex(random_bytes(16)) . '.' . $extension;
    $directory = __DIR__ . '/storage/uploads';
    if (!is_dir($directory) && !mkdir($directory, 0750, true) && !is_dir($directory)) {
        throw new RuntimeException('Folder penyimpanan berkas tidak tersedia.');
    }
    if (!move_uploaded_file((string) $upload['tmp_name'], $directory . '/' . $stored)) {
        throw new RuntimeException('Berkas gagal disimpan. Periksa izin folder penyimpanan.');
    }
    return ['original' => mb_substr($original, 0, 250), 'stored' => $stored];
}

function lms_valid_url(string $url): ?string
{
    $url = trim($url);
    if ($url === '') {
        return null;
    }
    $parts = parse_url($url);
    if (!filter_var($url, FILTER_VALIDATE_URL) || !isset($parts['scheme']) || !in_array(strtolower($parts['scheme']), ['http', 'https'], true)) {
        throw new RuntimeException('Tautan materi harus menggunakan URL HTTP atau HTTPS yang valid.');
    }
    return $url;
}

function lms_teacher_assignment(PDO $pdo, int $id, int $teacherId): array
{
    $statement = $pdo->prepare('SELECT * FROM teacher_assignments WHERE id = ? AND teacher_id = ?');
    $statement->execute([$id, $teacherId]);
    $row = $statement->fetch();
    if (!$row) {
        throw new RuntimeException('Kelas atau mata pelajaran tidak ditemukan dalam penugasan Anda.');
    }
    return $row;
}

function lms_send_file(array $row): void
{
    $stored = (string) ($row['file_stored'] ?? '');
    if (!preg_match('/^[a-f0-9]{32}\.[a-z0-9]{1,10}$/', $stored)) {
        http_response_code(404);
        exit('Berkas tidak ditemukan.');
    }
    $path = __DIR__ . '/storage/uploads/' . $stored;
    if (!is_file($path)) {
        http_response_code(404);
        exit('Berkas tidak ditemukan.');
    }
    $name = str_replace(["\r", "\n", '"'], '', basename((string) ($row['file_original'] ?? 'unduhan')));
    header('Content-Type: application/octet-stream');
    header('X-Content-Type-Options: nosniff');
    header('Content-Length: ' . (string) filesize($path));
    header('Content-Disposition: attachment; filename="' . addcslashes($name, '\\') . '"; filename*=UTF-8\'\'' . rawurlencode($name));
    readfile($path);
    exit;
}

try {
    $pdo = db();
} catch (Throwable $exception) {
    error_log('LMS database connection failed: ' . $exception->getMessage());
    http_response_code(503);
    exit('Database belum siap. Jalankan installer atau periksa konfigurasi database.');
}

$user = current_user();

if (isset($_GET['download'])) {
    if (!$user) {
        redirect();
    }
    $kind = (string) ($_GET['kind'] ?? 'submission');
    $id = (int) $_GET['download'];
    if ($kind === 'submission') {
        $query = $pdo->prepare('SELECT s.file_stored, s.file_original, s.student_id, ta.teacher_id FROM submissions s JOIN assignments a ON a.id = s.assignment_id JOIN teacher_assignments ta ON ta.id = a.teacher_assignment_id WHERE s.id = ?');
        $query->execute([$id]);
        $file = $query->fetch();
        $allowed = $file && ($user['role'] === 'admin' || ($user['role'] === 'student' && (int) $file['student_id'] === (int) $user['id']) || ($user['role'] === 'teacher' && (int) $file['teacher_id'] === (int) $user['id']));
    } elseif (in_array($kind, ['material', 'assignment'], true)) {
        $table = $kind === 'material' ? 'materials' : 'assignments';
        $storedColumn = $kind === 'material' ? 'file_stored' : 'attachment_stored';
        $originalColumn = $kind === 'material' ? 'file_original' : 'attachment_original';
        $query = $pdo->prepare("SELECT x.{$storedColumn} AS file_stored, x.{$originalColumn} AS file_original, ta.teacher_id, ta.class_id FROM {$table} x JOIN teacher_assignments ta ON ta.id = x.teacher_assignment_id WHERE x.id = ?");
        $query->execute([$id]);
        $file = $query->fetch();
        $studentClass = false;
        if ($file && $user['role'] === 'student') {
            $membership = $pdo->prepare('SELECT 1 FROM class_students WHERE class_id = ? AND student_id = ?');
            $membership->execute([$file['class_id'], $user['id']]);
            $studentClass = (bool) $membership->fetchColumn();
        }
        $allowed = $file && ($user['role'] === 'admin' || ($user['role'] === 'teacher' && (int) $file['teacher_id'] === (int) $user['id']) || ($user['role'] === 'student' && $studentClass));
    } else {
        http_response_code(404);
        exit('Berkas tidak ditemukan.');
    }
    if (!$allowed) {
        http_response_code(403);
        exit('Anda tidak memiliki akses ke berkas ini.');
    }
    lms_send_file($file);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string) ($_POST['action'] ?? '');
    if ($action === 'login') {
        $statement = $pdo->prepare('SELECT id, name, username, password_hash, role FROM users WHERE username = ? LIMIT 1');
        $statement->execute([trim((string) ($_POST['username'] ?? ''))]);
        $account = $statement->fetch();
        if ($account && password_verify((string) ($_POST['password'] ?? ''), $account['password_hash'])) {
            session_regenerate_id(true);
            unset($account['password_hash']);
            $_SESSION['user'] = $account;
            redirect();
        }
        set_flash('error', 'Username atau password tidak sesuai.');
        redirect();
    }
    if ($action === 'logout') {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
        }
        session_destroy();
        redirect();
    }

    $user = require_role('admin', 'teacher', 'student');
    try {
        switch ($action) {
            case 'create_student_account':
                require_role('admin');
                $studentName = trim((string) ($_POST['student_name'] ?? ''));
                $username = strtolower(trim((string) ($_POST['student_username'] ?? '')));
                $password = (string) ($_POST['student_password'] ?? '');
                $classId = (int) ($_POST['class_id'] ?? 0);
                if ($studentName === '' || mb_strlen($studentName) > 120 || !preg_match('/^[a-z]{3,60}$/D', $username)) {
                    throw new RuntimeException('Nama wajib diisi dan username harus 3-60 huruf tanpa angka atau spasi.');
                }
                if (strlen($password) < 8 || strlen($password) > 128) {
                    throw new RuntimeException('Password harus terdiri dari 8-128 karakter.');
                }
                $classCheck = $pdo->prepare('SELECT id FROM classes WHERE id = ?');
                $classCheck->execute([$classId]);
                if (!$classCheck->fetchColumn()) {
                    throw new RuntimeException('Pilih kelas yang valid.');
                }
                $pdo->beginTransaction();
                $existing = $pdo->prepare('SELECT id FROM users WHERE username = ?');
                $existing->execute([$username]);
                if ($existing->fetchColumn()) {
                    throw new RuntimeException('Username sudah digunakan. Pilih username lain.');
                }
                $create = $pdo->prepare('INSERT INTO users (name, username, password_hash, role) VALUES (?, ?, ?, "student")');
                $create->execute([$studentName, $username, password_hash($password, PASSWORD_DEFAULT)]);
                $studentId = (int) $pdo->lastInsertId();
                $pdo->prepare('INSERT INTO class_students (class_id, student_id) VALUES (?, ?)')->execute([$classId, $studentId]);
                $pdo->commit();
                set_flash('success', 'Akun siswa ' . $username . ' berhasil dibuat dan dimasukkan ke kelas.');
                break;

            case 'bulk_student_accounts':
                require_role('admin');
                $classId = (int) ($_POST['class_id'] ?? 0);
                $classCheck = $pdo->prepare('SELECT id FROM classes WHERE id = ?');
                $classCheck->execute([$classId]);
                if (!$classCheck->fetchColumn()) {
                    throw new RuntimeException('Pilih kelas yang valid untuk siswa baru.');
                }
                $lines = preg_split('/\R/u', trim((string) ($_POST['student_rows'] ?? '')), -1, PREG_SPLIT_NO_EMPTY);
                if (!$lines || count($lines) > 200) {
                    throw new RuntimeException('Masukkan 1-200 baris siswa.');
                }
                $lookup = $pdo->prepare('SELECT id, name, role FROM users WHERE username = ?');
                $insertUser = $pdo->prepare('INSERT INTO users (name, username, password_hash, role) VALUES (?, ?, ?, "student")');
                $enroll = $pdo->prepare('INSERT IGNORE INTO class_students (class_id, student_id) VALUES (?, ?)');
                $seen = [];
                $created = 0;
                $enrolled = 0;
                $pdo->beginTransaction();
                foreach ($lines as $index => $line) {
                    $parts = preg_split('/\s*[|\t]\s*/u', trim($line), 2);
                    $studentName = trim((string) ($parts[0] ?? ''));
                    $password = trim((string) ($parts[1] ?? ''));
                    if ($studentName === '' || strlen($studentName) > 120 || !preg_match('/^\d{10}$/D', $password)) {
                        throw new RuntimeException('Baris ' . ($index + 1) . ' harus berisi nama dan password angka tepat 10 digit, dipisahkan dengan tanda |.');
                    }
                    $asciiName = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $studentName);
                    $username = strtolower((string) preg_replace('/[^A-Za-z]/', '', (string) $asciiName));
                    if (strlen($username) < 3 || strlen($username) > 60 || isset($seen[$username])) {
                        throw new RuntimeException('Nama pada baris ' . ($index + 1) . ' menghasilkan username kosong, terlalu panjang, atau duplikat.');
                    }
                    $seen[$username] = true;
                    $lookup->execute([$username]);
                    $existing = $lookup->fetch();
                    if ($existing) {
                        if ($existing['role'] !== 'student' || mb_strtolower($existing['name']) !== mb_strtolower($studentName)) {
                            throw new RuntimeException('Username alfabetis hasil nama pada baris ' . ($index + 1) . ' sudah digunakan akun lain.');
                        }
                        $studentId = (int) $existing['id'];
                    } else {
                        $insertUser->execute([$studentName, $username, password_hash($password, PASSWORD_DEFAULT)]);
                        $studentId = (int) $pdo->lastInsertId();
                        $created++;
                    }
                    $enroll->execute([$classId, $studentId]);
                    $enrolled += $enroll->rowCount();
                }
                $pdo->commit();
                set_flash('success', $created . ' akun siswa dibuat; ' . $enrolled . ' siswa ditambahkan ke kelas. Username dibentuk dari nama lengkap tanpa spasi/tanda baca, password tidak ditampilkan kembali.');
                break;

            case 'change_password':
                $currentPassword = (string) ($_POST['current_password'] ?? '');
                $newPassword = (string) ($_POST['new_password'] ?? '');
                $confirmPassword = (string) ($_POST['confirm_password'] ?? '');
                $passwordQuery = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?');
                $passwordQuery->execute([$user['id']]);
                $passwordHash = $passwordQuery->fetchColumn();
                if (!$passwordHash || !password_verify($currentPassword, (string) $passwordHash)) {
                    throw new RuntimeException('Password saat ini tidak sesuai.');
                }
                if (strlen($newPassword) < 8 || $newPassword !== $confirmPassword) {
                    throw new RuntimeException('Password baru minimal 8 karakter dan harus sama dengan konfirmasi.');
                }
                $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([password_hash($newPassword, PASSWORD_DEFAULT), $user['id']]);
                set_flash('success', 'Password berhasil diperbarui.');
                break;

            case 'create_user':
            case 'update_user':
                require_role('admin');
                $id = (int) ($_POST['user_id'] ?? 0);
                $name = trim((string) ($_POST['name'] ?? ''));
                $username = trim((string) ($_POST['username'] ?? ''));
                $role = (string) ($_POST['role'] ?? '');
                $password = (string) ($_POST['password'] ?? '');
                if ($name === '' || !preg_match('/^[A-Za-z0-9._-]{3,60}$/', $username) || !in_array($role, ['teacher', 'student'], true)) {
                    throw new RuntimeException('Nama, username 3-60 karakter, dan peran guru/siswa wajib valid.');
                }
                if ($action === 'create_user') {
                    if (strlen($password) < 8) {
                        throw new RuntimeException('Password akun baru minimal 8 karakter.');
                    }
                    $query = $pdo->prepare('INSERT INTO users (name, username, password_hash, role) VALUES (?, ?, ?, ?)');
                    $query->execute([$name, $username, password_hash($password, PASSWORD_DEFAULT), $role]);
                    set_flash('success', 'Akun berhasil dibuat.');
                } else {
                    if ($id === (int) $user['id']) {
                        throw new RuntimeException('Peran akun yang sedang digunakan tidak dapat diubah.');
                    }
                    $query = $pdo->prepare('UPDATE users SET name = ?, username = ?, role = ?, password_hash = IF(? = "", password_hash, ?) WHERE id = ? AND role <> "admin"');
                    $query->execute([$name, $username, $role, $password, $password === '' ? '' : password_hash($password, PASSWORD_DEFAULT), $id]);
                    set_flash('success', 'Data akun berhasil diperbarui.');
                }
                break;

            case 'delete_user':
                require_role('admin');
                $id = (int) ($_POST['user_id'] ?? 0);
                $roleQuery = $pdo->prepare('SELECT role FROM users WHERE id = ?');
                $roleQuery->execute([$id]);
                $targetRole = $roleQuery->fetchColumn();
                if ($targetRole === 'teacher') {
                    $usage = $pdo->prepare('SELECT COUNT(*) FROM teacher_assignments WHERE teacher_id = ?');
                    $usage->execute([$id]);
                    if ((int) $usage->fetchColumn() > 0) {
                        throw new RuntimeException('Guru masih memiliki penugasan kelas/mapel. Hapus atau pindahkan penugasannya terlebih dahulu.');
                    }
                }
                if ($targetRole === 'student') {
                    $usage = $pdo->prepare('SELECT COUNT(*) FROM submissions WHERE student_id = ?');
                    $usage->execute([$id]);
                    if ((int) $usage->fetchColumn() > 0) {
                        throw new RuntimeException('Siswa memiliki riwayat pengumpulan. Akun tidak dapat dihapus agar rekap tetap utuh.');
                    }
                }
                $query = $pdo->prepare('DELETE FROM users WHERE id = ? AND role IN ("teacher", "student")');
                $query->execute([$id]);
                if (!$query->rowCount()) {
                    throw new RuntimeException('Akun tidak ditemukan atau masih terhubung dengan data belajar.');
                }
                set_flash('success', 'Akun berhasil dihapus.');
                break;

            case 'save_class':
                require_role('admin');
                $id = (int) ($_POST['class_id'] ?? 0);
                $name = trim((string) ($_POST['name'] ?? ''));
                $code = strtoupper(trim((string) ($_POST['code'] ?? '')));
                $year = trim((string) ($_POST['academic_year'] ?? ''));
                if ($name === '' || !preg_match('/^[A-Z0-9-]{2,30}$/', $code) || !preg_match('/^\d{4}\/\d{4}$/', $year)) {
                    throw new RuntimeException('Nama kelas, kode kelas, dan tahun ajaran (YYYY/YYYY) wajib diisi.');
                }
                if ($id) {
                    $query = $pdo->prepare('UPDATE classes SET name = ?, code = ?, academic_year = ? WHERE id = ?');
                    $query->execute([$name, $code, $year, $id]);
                } else {
                    $query = $pdo->prepare('INSERT INTO classes (name, code, academic_year) VALUES (?, ?, ?)');
                    $query->execute([$name, $code, $year]);
                }
                set_flash('success', 'Data kelas berhasil disimpan.');
                break;

            case 'delete_class':
                require_role('admin');
                $id = (int) ($_POST['class_id'] ?? 0);
                $usage = $pdo->prepare('SELECT COUNT(*) FROM teacher_assignments WHERE class_id = ?');
                $usage->execute([$id]);
                if ((int) $usage->fetchColumn() > 0) {
                    throw new RuntimeException('Kelas masih memiliki penugasan guru. Hapus penugasan yang tidak berisi tugas terlebih dahulu.');
                }
                $query = $pdo->prepare('DELETE FROM classes WHERE id = ?');
                $query->execute([$id]);
                set_flash($query->rowCount() ? 'success' : 'error', $query->rowCount() ? 'Kelas berhasil dihapus.' : 'Kelas masih terhubung dengan data belajar.');
                break;

            case 'save_subject':
                require_role('admin');
                $id = (int) ($_POST['subject_id'] ?? 0);
                $name = trim((string) ($_POST['name'] ?? ''));
                $code = strtoupper(trim((string) ($_POST['code'] ?? '')));
                if ($name === '' || !preg_match('/^[A-Z0-9-]{2,30}$/', $code)) {
                    throw new RuntimeException('Nama mata pelajaran dan kode 2-30 karakter wajib diisi.');
                }
                if ($id) {
                    $query = $pdo->prepare('UPDATE subjects SET name = ?, code = ? WHERE id = ?');
                    $query->execute([$name, $code, $id]);
                } else {
                    $query = $pdo->prepare('INSERT INTO subjects (name, code) VALUES (?, ?)');
                    $query->execute([$name, $code]);
                }
                set_flash('success', 'Data mata pelajaran berhasil disimpan.');
                break;

            case 'delete_subject':
                require_role('admin');
                $id = (int) ($_POST['subject_id'] ?? 0);
                $usage = $pdo->prepare('SELECT COUNT(*) FROM teacher_assignments WHERE subject_id = ?');
                $usage->execute([$id]);
                if ((int) $usage->fetchColumn() > 0) {
                    throw new RuntimeException('Mata pelajaran masih memiliki penugasan guru. Hapus penugasan yang tidak berisi tugas terlebih dahulu.');
                }
                $query = $pdo->prepare('DELETE FROM subjects WHERE id = ?');
                $query->execute([$id]);
                set_flash($query->rowCount() ? 'success' : 'error', $query->rowCount() ? 'Mata pelajaran berhasil dihapus.' : 'Mata pelajaran masih terhubung dengan data belajar.');
                break;

            case 'assign_teacher':
                require_role('admin');
                $teacherId = (int) ($_POST['teacher_id'] ?? 0);
                $classId = (int) ($_POST['class_id'] ?? 0);
                $subjectId = (int) ($_POST['subject_id'] ?? 0);
                $teacherCheck = $pdo->prepare('SELECT 1 FROM users WHERE id = ? AND role = "teacher"');
                $teacherCheck->execute([$teacherId]);
                if (!$teacherCheck->fetchColumn()) {
                    throw new RuntimeException('Pilih guru yang valid.');
                }
                $query = $pdo->prepare('INSERT INTO teacher_assignments (teacher_id, class_id, subject_id) VALUES (?, ?, ?)');
                $query->execute([$teacherId, $classId, $subjectId]);
                set_flash('success', 'Penugasan guru berhasil dibuat.');
                break;

            case 'delete_teacher_assignment':
                require_role('admin');
                $id = (int) ($_POST['teacher_assignment_id'] ?? 0);
                $usage = $pdo->prepare('SELECT (SELECT COUNT(*) FROM assignments WHERE teacher_assignment_id = ?) + (SELECT COUNT(*) FROM materials WHERE teacher_assignment_id = ?)');
                $usage->execute([$id, $id]);
                if ((int) $usage->fetchColumn() > 0) {
                    throw new RuntimeException('Penugasan masih berisi tugas atau materi. Pindahkan data sebelum menghapus relasi ini.');
                }
                $query = $pdo->prepare('DELETE FROM teacher_assignments WHERE id = ?');
                $query->execute([$id]);
                set_flash($query->rowCount() ? 'success' : 'error', $query->rowCount() ? 'Penugasan berhasil dihapus.' : 'Penugasan tidak ditemukan atau masih berisi tugas/materi.');
                break;

            case 'set_class_students':
                require_role('admin');
                $classId = (int) ($_POST['class_id'] ?? 0);
                $classCheck = $pdo->prepare('SELECT 1 FROM classes WHERE id = ?');
                $classCheck->execute([$classId]);
                if (!$classCheck->fetchColumn()) {
                    throw new RuntimeException('Kelas tidak ditemukan.');
                }
                $studentIds = array_values(array_unique(array_filter(array_map('intval', (array) ($_POST['student_ids'] ?? [])))));
                $exclude = '';
                $submissionParams = [$classId];
                if ($studentIds) {
                    $exclude = ' AND cs.student_id NOT IN (' . implode(',', array_fill(0, count($studentIds), '?')) . ')';
                    $submissionParams = array_merge($submissionParams, $studentIds);
                }
                $submissionCheck = $pdo->prepare('SELECT COUNT(*) FROM submissions s JOIN assignments a ON a.id = s.assignment_id JOIN teacher_assignments ta ON ta.id = a.teacher_assignment_id JOIN class_students cs ON cs.class_id = ta.class_id AND cs.student_id = s.student_id WHERE ta.class_id = ?' . $exclude);
                $submissionCheck->execute($submissionParams);
                if ((int) $submissionCheck->fetchColumn() > 0) {
                    throw new RuntimeException('Anggota dengan riwayat pengumpulan tidak dapat dikeluarkan dari kelas agar rekap tetap utuh.');
                }
                $pdo->beginTransaction();
                $pdo->prepare('DELETE FROM class_students WHERE class_id = ?')->execute([$classId]);
                $insert = $pdo->prepare('INSERT INTO class_students (class_id, student_id) SELECT ?, id FROM users WHERE id = ? AND role = "student"');
                foreach ($studentIds as $studentId) {
                    $insert->execute([$classId, $studentId]);
                }
                $pdo->commit();
                set_flash('success', 'Daftar siswa kelas berhasil diperbarui.');
                break;

            case 'save_material':
            case 'delete_material':
                $teacher = require_role('teacher');
                $id = (int) ($_POST['material_id'] ?? 0);
                if ($action === 'delete_material') {
                    $query = $pdo->prepare('DELETE m FROM materials m JOIN teacher_assignments ta ON ta.id = m.teacher_assignment_id WHERE m.id = ? AND ta.teacher_id = ?');
                    $query->execute([$id, $teacher['id']]);
                    set_flash('success', 'Materi berhasil dihapus.');
                    break;
                }
                $mappingId = (int) ($_POST['teacher_assignment_id'] ?? 0);
                lms_teacher_assignment($pdo, $mappingId, (int) $teacher['id']);
                $title = trim((string) ($_POST['title'] ?? ''));
                $description = trim((string) ($_POST['description'] ?? ''));
                $url = lms_valid_url((string) ($_POST['resource_url'] ?? ''));
                $newFile = lms_upload($_FILES['material_file'] ?? null, false);
                if ($title === '' || (!$url && !$newFile && !$id)) {
                    throw new RuntimeException('Judul dan tautan atau berkas materi wajib diisi.');
                }
                if ($id) {
                    $query = $pdo->prepare('UPDATE materials m JOIN teacher_assignments ta ON ta.id = m.teacher_assignment_id SET m.title = ?, m.description = ?, m.resource_url = ?, m.teacher_assignment_id = ?, m.file_original = COALESCE(?, m.file_original), m.file_stored = COALESCE(?, m.file_stored) WHERE m.id = ? AND ta.teacher_id = ?');
                    $query->execute([$title, $description, $url, $mappingId, $newFile['original'] ?? null, $newFile['stored'] ?? null, $id, $teacher['id']]);
                } else {
                    $query = $pdo->prepare('INSERT INTO materials (teacher_assignment_id, title, description, resource_url, file_original, file_stored) VALUES (?, ?, ?, ?, ?, ?)');
                    $query->execute([$mappingId, $title, $description, $url, $newFile['original'] ?? null, $newFile['stored'] ?? null]);
                }
                set_flash('success', 'Materi berhasil dipublikasikan.');
                break;

            case 'save_assignment':
            case 'close_assignment':
                $teacher = require_role('teacher');
                $id = (int) ($_POST['assignment_id'] ?? 0);
                if ($action === 'close_assignment') {
                    $query = $pdo->prepare('UPDATE assignments a JOIN teacher_assignments ta ON ta.id = a.teacher_assignment_id SET a.is_closed = 1 WHERE a.id = ? AND ta.teacher_id = ?');
                    $query->execute([$id, $teacher['id']]);
                    set_flash($query->rowCount() ? 'success' : 'error', $query->rowCount() ? 'Tugas berhasil ditutup.' : 'Tugas tidak ditemukan.');
                    break;
                }
                $mappingId = (int) ($_POST['teacher_assignment_id'] ?? 0);
                lms_teacher_assignment($pdo, $mappingId, (int) $teacher['id']);
                $title = trim((string) ($_POST['title'] ?? ''));
                $description = trim((string) ($_POST['description'] ?? ''));
                $dueInput = trim((string) ($_POST['due_at'] ?? ''));
                $dueAt = null;
                if ($dueInput !== '') {
                    $parsed = DateTimeImmutable::createFromFormat('Y-m-d\TH:i', $dueInput);
                    $dateErrors = DateTimeImmutable::getLastErrors();
                    if (!$parsed || ($dateErrors && ($dateErrors['warning_count'] || $dateErrors['error_count']))) {
                        throw new RuntimeException('Tanggal dan waktu tenggat tidak valid.');
                    }
                    $dueAt = $parsed->format('Y-m-d H:i:s');
                }
                $weight = filter_var($_POST['weight'] ?? 100, FILTER_VALIDATE_FLOAT);
                if ($title === '' || $description === '' || $weight === false || $weight <= 0 || $weight > 1000) {
                    throw new RuntimeException('Judul, instruksi, dan bobot 0-1000 wajib valid.');
                }
                $attachment = lms_upload($_FILES['assignment_file'] ?? null, false);
                if ($id) {
                    $query = $pdo->prepare('UPDATE assignments a JOIN teacher_assignments ta ON ta.id = a.teacher_assignment_id SET a.teacher_assignment_id = ?, a.title = ?, a.description = ?, a.due_at = ?, a.weight = ?, a.allow_late = ?, a.allow_resubmit_after_due = ?, a.attachment_original = COALESCE(?, a.attachment_original), a.attachment_stored = COALESCE(?, a.attachment_stored) WHERE a.id = ? AND ta.teacher_id = ? AND a.is_closed = 0');
                    $query->execute([$mappingId, $title, $description, $dueAt, $weight, isset($_POST['allow_late']) ? 1 : 0, isset($_POST['allow_resubmit_after_due']) ? 1 : 0, $attachment['original'] ?? null, $attachment['stored'] ?? null, $id, $teacher['id']]);
                } else {
                    $query = $pdo->prepare('INSERT INTO assignments (teacher_assignment_id, title, description, attachment_original, attachment_stored, due_at, allow_late, allow_resubmit_after_due, weight, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
                    $query->execute([$mappingId, $title, $description, $attachment['original'] ?? null, $attachment['stored'] ?? null, $dueAt, isset($_POST['allow_late']) ? 1 : 0, isset($_POST['allow_resubmit_after_due']) ? 1 : 0, $weight, $teacher['id']]);
                }
                set_flash('success', $id ? 'Tugas berhasil diperbarui.' : 'Tugas berhasil diterbitkan.');
                break;

            case 'submit_assignment':
                $student = require_role('student');
                $assignmentId = (int) ($_POST['assignment_id'] ?? 0);
                $query = $pdo->prepare('SELECT a.*, ta.class_id FROM assignments a JOIN teacher_assignments ta ON ta.id = a.teacher_assignment_id JOIN class_students cs ON cs.class_id = ta.class_id WHERE a.id = ? AND cs.student_id = ?');
                $query->execute([$assignmentId, $student['id']]);
                $assignment = $query->fetch();
                if (!$assignment) {
                    throw new RuntimeException('Tugas tidak ditemukan di kelas Anda.');
                }
                if ((int) $assignment['is_closed'] === 1) {
                    throw new RuntimeException('Tugas ini sudah ditutup oleh guru.');
                }
                $previous = $pdo->prepare('SELECT id, submitted_at, revision_count FROM submissions WHERE assignment_id = ? AND student_id = ?');
                $previous->execute([$assignmentId, $student['id']]);
                $existing = $previous->fetch();
                $lateNow = $assignment['due_at'] && time() > strtotime($assignment['due_at']);
                if (!$existing && $lateNow && !(int) $assignment['allow_late']) {
                    throw new RuntimeException('Tenggat sudah lewat dan guru tidak menerima pengumpulan terlambat.');
                }
                if ($existing && $lateNow && !(int) $assignment['allow_resubmit_after_due']) {
                    throw new RuntimeException('Unggah ulang setelah tenggat tidak diizinkan untuk tugas ini.');
                }
                $file = lms_upload($_FILES['submission_file'] ?? null);
                $pdo->beginTransaction();
                if ($existing) {
                    $revision = (int) $existing['revision_count'] + 1;
                    $pdo->prepare('INSERT INTO submission_versions (submission_id, revision_number, file_original, file_stored, submitted_at, uploaded_by) VALUES (?, ?, ?, ?, NOW(), ?)')->execute([$existing['id'], $revision, $file['original'], $file['stored'], $student['id']]);
                    $pdo->prepare('UPDATE submissions SET file_original = ?, file_stored = ?, submitted_at = NOW(), revision_count = ? WHERE id = ?')->execute([$file['original'], $file['stored'], $revision, $existing['id']]);
                    $pdo->prepare('UPDATE grades g JOIN submissions s ON s.id = g.submission_id SET g.is_published = 0 WHERE s.id = ?')->execute([$existing['id']]);
                } else {
                    $pdo->prepare('INSERT INTO submissions (assignment_id, student_id, file_original, file_stored, submitted_at) VALUES (?, ?, ?, ?, NOW())')->execute([$assignmentId, $student['id'], $file['original'], $file['stored']]);
                    $submissionId = (int) $pdo->lastInsertId();
                    $pdo->prepare('INSERT INTO submission_versions (submission_id, revision_number, file_original, file_stored, submitted_at, uploaded_by) VALUES (?, 1, ?, ?, NOW(), ?)')->execute([$submissionId, $file['original'], $file['stored'], $student['id']]);
                }
                $pdo->commit();
                set_flash('success', $existing ? 'Revisi berhasil dikumpulkan. Status terlambat dihitung dari waktu unggah terakhir.' : 'Tugas berhasil dikumpulkan. Waktu unggah dicatat oleh database.');
                break;

            case 'grade_submission':
                $teacher = require_role('teacher');
                $submissionId = (int) ($_POST['submission_id'] ?? 0);
                $score = filter_var($_POST['score'] ?? null, FILTER_VALIDATE_FLOAT);
                $feedback = trim((string) ($_POST['feedback'] ?? ''));
                $published = isset($_POST['is_published']) ? 1 : 0;
                if ($score === false || $score < 0 || $score > 100) {
                    throw new RuntimeException('Nilai harus berupa angka dari 0 sampai 100.');
                }
                $access = $pdo->prepare('SELECT s.id FROM submissions s JOIN assignments a ON a.id = s.assignment_id JOIN teacher_assignments ta ON ta.id = a.teacher_assignment_id WHERE s.id = ? AND ta.teacher_id = ?');
                $access->execute([$submissionId, $teacher['id']]);
                if (!$access->fetchColumn()) {
                    throw new RuntimeException('Pengumpulan tidak ditemukan atau bukan tanggung jawab Anda.');
                }
                $pdo->beginTransaction();
                $existingGrade = $pdo->prepare('SELECT id FROM grades WHERE submission_id = ?');
                $existingGrade->execute([$submissionId]);
                $gradeId = $existingGrade->fetchColumn();
                if ($gradeId) {
                    $pdo->prepare('UPDATE grades SET score = ?, feedback = ?, is_published = ?, graded_by = ?, graded_at = NOW() WHERE id = ?')->execute([$score, $feedback, $published, $teacher['id'], $gradeId]);
                } else {
                    $pdo->prepare('INSERT INTO grades (submission_id, score, feedback, is_published, graded_by, graded_at) VALUES (?, ?, ?, ?, ?, NOW())')->execute([$submissionId, $score, $feedback, $published, $teacher['id']]);
                    $gradeId = (int) $pdo->lastInsertId();
                }
                $pdo->prepare('INSERT INTO grade_history (grade_id, score, feedback, is_published, changed_by, changed_at) VALUES (?, ?, ?, ?, ?, NOW())')->execute([$gradeId, $score, $feedback, $published, $teacher['id']]);
                $pdo->commit();
                set_flash('success', 'Nilai dan umpan balik berhasil disimpan.');
                break;

            default:
                throw new RuntimeException('Aksi tidak dikenali.');
        }
    } catch (RuntimeException $exception) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        set_flash('error', $exception->getMessage());
    } catch (PDOException $exception) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log('LMS database action failed: ' . $exception->getMessage());
        $message = $exception->getCode() === '23000'
            ? 'Data duplikat atau masih memiliki relasi aktif. Periksa data terkait sebelum mengubahnya.'
            : 'Perubahan tidak dapat disimpan. Periksa kembali isian dan koneksi database.';
        set_flash('error', $message);
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log('LMS action failed: ' . $exception->getMessage());
        set_flash('error', 'Terjadi kesalahan saat memproses permintaan.');
    }
    redirect();
}

$flash = take_flash();
if (!$user) {
    ?>
    <!doctype html>
    <html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><meta name="theme-color" content="#edf4fc"><title>Masuk | LMS English</title><link rel="stylesheet" href="assets/style.css"><link rel="stylesheet" href="assets/lms.css"></head>
    <body class="login-page"><div class="login-shell"><section class="login-art"><div class="art-top"><span class="brand-mark brand-mark-light">L</span><span>SMAN 1 PAREPARE</span></div><div class="art-content"><p class="eyebrow">LEARNING MANAGEMENT SYSTEM</p><h1>Belajar hari ini.<br><em>Siap esok hari.</em></h1><p>Ruang belajar Bahasa Inggris untuk tumbuh, berkarya, dan melangkah lebih jauh.</p></div><div class="art-bottom"><span>LMS ENGLISH</span><span class="art-rule"></span><span>RUANG KELAS DIGITAL</span></div><div class="art-shape shape-one"></div><div class="art-shape shape-two"></div></section><section class="login-panel"><div class="mobile-brand"><span class="brand-mark">L</span><span>SMAN 1 PAREPARE</span></div><div class="login-form-wrap"><p class="eyebrow">SELAMAT DATANG KEMBALI</p><h2>Masuk ke LMS English</h2><p class="muted">Gunakan akun sekolah untuk melanjutkan.</p><?php if ($flash): ?><div class="notice notice-<?= e($flash['type']) ?>" role="status"><?= e($flash['message']) ?></div><?php endif; ?><form method="post" class="form-stack"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="login"><label for="username">Username</label><input id="username" name="username" autocomplete="username" required autofocus><label for="password">Password</label><div class="password-field"><input id="password" name="password" type="password" autocomplete="current-password" required><button type="button" class="password-toggle" aria-label="Tampilkan password">Lihat</button></div><button class="button button-dark button-wide" type="submit">Masuk <span aria-hidden="true">↗</span></button></form><div class="demo-accounts"><span class="demo-label">AKUN DEMO LOKAL · GANTI PASSWORD SEBELUM PAKAI NYATA</span><span>Admin <b>admin / admin</b></span><span>Guru <b>guru / guru</b></span><span>Siswa <b>siswa / siswa</b></span></div><p class="login-foot">© <?= date('Y') ?> SMAN 1 Parepare</p></div></section></div><script src="assets/app.js" defer></script></body></html>
    <?php
    exit;
}

$role = $user['role'];
$admin = $role === 'admin';
$teacher = $role === 'teacher';
$student = $role === 'student';
$classes = $subjects = $users = $teachers = $students = $teacherAssignments = $materials = $assignments = $rosterRows = [];

if ($admin) {
    $stats = [
        'Guru' => (int) $pdo->query('SELECT COUNT(*) FROM users WHERE role = "teacher"')->fetchColumn(),
        'Siswa' => (int) $pdo->query('SELECT COUNT(*) FROM users WHERE role = "student"')->fetchColumn(),
        'Kelas' => (int) $pdo->query('SELECT COUNT(*) FROM classes')->fetchColumn(),
        'Mata pelajaran' => (int) $pdo->query('SELECT COUNT(*) FROM subjects')->fetchColumn(),
        'Tugas aktif' => (int) $pdo->query('SELECT COUNT(*) FROM assignments WHERE is_closed = 0')->fetchColumn(),
        'Pengumpulan' => (int) $pdo->query('SELECT COUNT(*) FROM submissions')->fetchColumn(),
    ];
    $users = $pdo->query('SELECT id, name, username, role FROM users ORDER BY role, name')->fetchAll();
    $teachers = $pdo->query('SELECT id, name FROM users WHERE role = "teacher" ORDER BY name')->fetchAll();
    $students = $pdo->query('SELECT id, name, username FROM users WHERE role = "student" ORDER BY name')->fetchAll();
    $classes = $pdo->query('SELECT c.*, COUNT(cs.student_id) AS student_count FROM classes c LEFT JOIN class_students cs ON cs.class_id = c.id GROUP BY c.id ORDER BY c.academic_year DESC, c.name')->fetchAll();
    $subjects = $pdo->query('SELECT * FROM subjects ORDER BY name')->fetchAll();
    $teacherAssignments = $pdo->query('SELECT ta.*, u.name AS teacher_name, c.name AS class_name, c.code AS class_code, s.name AS subject_name, s.code AS subject_code FROM teacher_assignments ta JOIN users u ON u.id = ta.teacher_id JOIN classes c ON c.id = ta.class_id JOIN subjects s ON s.id = ta.subject_id ORDER BY c.name, s.name, u.name')->fetchAll();
    $assignments = $pdo->query('SELECT a.*, ta.class_id, ta.teacher_id, c.name AS class_name, c.code AS class_code, s.name AS subject_name, s.code AS subject_code, u.name AS teacher_name, COUNT(DISTINCT sub.id) AS submission_count, COUNT(DISTINCT cs.student_id) AS student_count FROM assignments a JOIN teacher_assignments ta ON ta.id = a.teacher_assignment_id JOIN classes c ON c.id = ta.class_id JOIN subjects s ON s.id = ta.subject_id JOIN users u ON u.id = ta.teacher_id LEFT JOIN submissions sub ON sub.assignment_id = a.id LEFT JOIN class_students cs ON cs.class_id = ta.class_id GROUP BY a.id ORDER BY a.created_at DESC')->fetchAll();
    $rosterRows = $pdo->query('SELECT s.id AS submission_id, s.file_original, s.file_stored, s.submitted_at, cs.student_id, a.id AS assignment_id, a.title AS assignment_title, a.due_at, a.is_closed, c.name AS class_name, subj.name AS subject_name, u.name AS student_name, g.score, g.feedback, g.is_published FROM assignments a JOIN teacher_assignments ta ON ta.id = a.teacher_assignment_id JOIN classes c ON c.id = ta.class_id JOIN subjects subj ON subj.id = ta.subject_id JOIN class_students cs ON cs.class_id = ta.class_id JOIN users u ON u.id = cs.student_id AND u.role = "student" LEFT JOIN submissions s ON s.assignment_id = a.id AND s.student_id = cs.student_id LEFT JOIN grades g ON g.submission_id = s.id ORDER BY a.created_at DESC, u.name')->fetchAll();
} elseif ($teacher) {
    $mappingQuery = $pdo->prepare('SELECT ta.*, c.name AS class_name, c.code AS class_code, s.name AS subject_name, s.code AS subject_code FROM teacher_assignments ta JOIN classes c ON c.id = ta.class_id JOIN subjects s ON s.id = ta.subject_id WHERE ta.teacher_id = ? ORDER BY c.name, s.name');
    $mappingQuery->execute([$user['id']]);
    $teacherAssignments = $mappingQuery->fetchAll();
    $mappingIds = array_map(static fn(array $item): int => (int) $item['id'], $teacherAssignments);
    $stats = [
        'Kelas & mapel' => count($teacherAssignments),
        'Tugas aktif' => 0,
        'Perlu dinilai' => 0,
        'Pengumpulan' => 0,
    ];
    $query = $pdo->prepare('SELECT a.*, ta.class_id, ta.class_name, ta.class_code, ta.subject_name, ta.subject_code, ta.id AS mapping_id, COUNT(DISTINCT s.id) AS submission_count, COUNT(DISTINCT cs.student_id) AS student_count FROM assignments a JOIN (SELECT ta.*, c.name AS class_name, c.code AS class_code, sub.name AS subject_name, sub.code AS subject_code FROM teacher_assignments ta JOIN classes c ON c.id = ta.class_id JOIN subjects sub ON sub.id = ta.subject_id WHERE ta.teacher_id = ?) ta ON ta.id = a.teacher_assignment_id LEFT JOIN submissions s ON s.assignment_id = a.id LEFT JOIN class_students cs ON cs.class_id = ta.class_id GROUP BY a.id ORDER BY a.created_at DESC');
    $query->execute([$user['id']]);
    $assignments = $query->fetchAll();
    $materialsQuery = $pdo->prepare('SELECT m.*, ta.class_id, c.name AS class_name, s.name AS subject_name, ta.teacher_id FROM materials m JOIN teacher_assignments ta ON ta.id = m.teacher_assignment_id JOIN classes c ON c.id = ta.class_id JOIN subjects s ON s.id = ta.subject_id WHERE ta.teacher_id = ? ORDER BY m.published_at DESC');
    $materialsQuery->execute([$user['id']]);
    $materials = $materialsQuery->fetchAll();
    $rosterQuery = $pdo->prepare('SELECT a.id AS assignment_id, a.title AS assignment_title, a.due_at, a.is_closed, ta.id AS mapping_id, c.name AS class_name, sub.name AS subject_name, cs.student_id, u.name AS student_name, s.id AS submission_id, s.file_original, s.file_stored, s.submitted_at, g.score, g.feedback, g.is_published FROM assignments a JOIN teacher_assignments ta ON ta.id = a.teacher_assignment_id JOIN classes c ON c.id = ta.class_id JOIN subjects sub ON sub.id = ta.subject_id JOIN class_students cs ON cs.class_id = ta.class_id JOIN users u ON u.id = cs.student_id AND u.role = "student" LEFT JOIN submissions s ON s.assignment_id = a.id AND s.student_id = cs.student_id LEFT JOIN grades g ON g.submission_id = s.id WHERE ta.teacher_id = ? ORDER BY a.created_at DESC, u.name');
    $rosterQuery->execute([$user['id']]);
    $rosterRows = $rosterQuery->fetchAll();
    $stats['Tugas aktif'] = count(array_filter($assignments, static fn(array $item): bool => !(int) $item['is_closed']));
    $stats['Perlu dinilai'] = count(array_filter($rosterRows, static fn(array $item): bool => $item['submission_id'] !== null && $item['score'] === null));
    $stats['Pengumpulan'] = count(array_filter($rosterRows, static fn(array $item): bool => $item['submission_id'] !== null));
} else {
    $taskQuery = $pdo->prepare('SELECT a.*, ta.class_id, c.name AS class_name, c.code AS class_code, s.name AS subject_name, s.code AS subject_code, u.name AS teacher_name, sub.id AS submission_id, sub.file_original, sub.file_stored, sub.submitted_at, sub.revision_count, g.score, g.feedback, g.graded_at, g.is_published FROM class_students cs JOIN teacher_assignments ta ON ta.class_id = cs.class_id JOIN assignments a ON a.teacher_assignment_id = ta.id JOIN classes c ON c.id = ta.class_id JOIN subjects s ON s.id = ta.subject_id JOIN users u ON u.id = ta.teacher_id LEFT JOIN submissions sub ON sub.assignment_id = a.id AND sub.student_id = cs.student_id LEFT JOIN grades g ON g.submission_id = sub.id WHERE cs.student_id = ? ORDER BY a.is_closed, (a.due_at IS NULL), a.due_at, a.created_at DESC');
    $taskQuery->execute([$user['id']]);
    $assignments = $taskQuery->fetchAll();
    $materialQuery = $pdo->prepare('SELECT m.*, c.name AS class_name, s.name AS subject_name, ta.class_id FROM class_students cs JOIN teacher_assignments ta ON ta.class_id = cs.class_id JOIN materials m ON m.teacher_assignment_id = ta.id JOIN classes c ON c.id = ta.class_id JOIN subjects s ON s.id = ta.subject_id WHERE cs.student_id = ? ORDER BY m.published_at DESC');
    $materialQuery->execute([$user['id']]);
    $materials = $materialQuery->fetchAll();
    $submitted = array_filter($assignments, static fn(array $item): bool => $item['submission_id'] !== null);
    $graded = array_filter($assignments, static fn(array $item): bool => $item['score'] !== null && (int) $item['is_published'] === 1);
    $upcoming = array_filter($assignments, static fn(array $item): bool => !$item['submission_id'] && !(int) $item['is_closed']);
    $nearest = $upcoming ? min(array_map(static fn(array $item): int => $item['due_at'] ? strtotime($item['due_at']) : PHP_INT_MAX, $upcoming)) : PHP_INT_MAX;
    $stats = [
        'Materi' => count($materials),
        'Tugas belum dikumpulkan' => count($upcoming),
        'Tenggat terdekat' => $nearest === PHP_INT_MAX ? '—' : date('d/m H:i', $nearest),
        'Nilai terbaru' => $graded ? number_format((float) end($graded)['score'], 1, ',', '.') : '—',
    ];
}

$allMappings = $admin ? $teacherAssignments : ($teacher ? $teacherAssignments : []);
$roleName = ['admin' => 'Admin', 'teacher' => 'Guru', 'student' => 'Siswa'][$role] ?? 'Pengguna';
$navItems = $admin
    ? [['overview', 'Ringkasan'], ['users', 'Pengguna'], ['classes', 'Kelas'], ['student-account', 'Siswa kelas'], ['bulk-students', 'Impor batch'], ['subjects', 'Mata pelajaran'], ['assignments', 'Tugas & rekap']]
    : ($teacher ? [['overview', 'Ringkasan'], ['materials', 'Materi'], ['assignments', 'Tugas'], ['submissions', 'Pengumpulan & nilai']] : [['overview', 'Ringkasan'], ['materials', 'Materi'], ['assignments', 'Tugas saya'], ['grades', 'Nilai saya']]);
?>
<!doctype html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><meta name="theme-color" content="#edf4fc"><title><?= e($roleName) ?> | LMS English</title><link rel="stylesheet" href="assets/style.css"><link rel="stylesheet" href="assets/lms.css"></head>
<body class="app-page"><div class="app-shell"><aside class="sidebar" id="sidebar"><a class="sidebar-brand" href="#overview"><span class="brand-mark">L</span><span><strong>SMAN 1</strong><small>PAREPARE · LMS ENGLISH</small></span></a><div class="sidebar-section-label">RUANG KERJA</div><nav class="side-nav" aria-label="Navigasi utama"><?php foreach ($navItems as $index => [$anchor, $label]): ?><a href="#<?= e($anchor) ?>" class="side-link <?= $index === 0 ? 'active' : '' ?>"><span class="nav-dot"></span><?= e($label) ?></a><?php endforeach; ?></nav><div class="sidebar-bottom"><div class="sidebar-school"><span class="school-stamp">EN</span><span><strong>Bahasa Inggris</strong><small>Tahun ajaran 2026/2027</small></span></div><div class="sidebar-user"><span class="avatar"><?= e(mb_strtoupper(mb_substr($user['name'], 0, 1))) ?></span><span class="user-meta"><strong><?= e($user['name']) ?></strong><small><?= e($roleName) ?></small></span><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="logout"><button class="logout-button" type="submit" title="Keluar" aria-label="Keluar">↗</button></form></div></div></aside><main class="main-area"><header class="topbar"><button class="menu-toggle" id="menu-toggle" type="button" aria-label="Buka navigasi" aria-expanded="false"><span></span><span></span></button><div class="breadcrumb"><span>LMS English</span><b>/</b><strong><?= e($roleName) ?></strong></div><div class="topbar-date"><span class="date-dot"></span><?= e(date('d/m/Y H:i')) ?> WITA</div></header><div class="content-wrap">
<?php if ($flash): ?><div class="notice notice-<?= e($flash['type']) ?>" role="status"><?= e($flash['message']) ?></div><?php endif; ?>
<section class="welcome-row" id="overview"><div><p class="eyebrow">DASHBOARD · <?= e(strtoupper($roleName)) ?></p><h1><?= $student ? 'Halo, ' . e($user['name']) . '.' : 'Selamat datang, ' . e($user['name']) . '.' ?></h1><p class="muted welcome-copy"><?= $admin ? 'Kelola data dan pantau aktivitas pembelajaran.' : ($teacher ? 'Materi, tugas, dan penilaian kelas Anda.' : 'Pantau materi, tenggat, dan hasil belajarmu.') ?></p></div><div class="welcome-index"><span><?= e(date('d')) ?></span><small><?= e(strtoupper(date('M Y'))) ?></small></div></section>
<section class="stats-grid lms-stats" aria-label="Statistik dashboard"><?php $statIndex = 0; foreach ($stats as $label => $value): ?><article class="stat-item stat-tone-<?= ++$statIndex ?>"><div class="stat-top"><span><?= e($label) ?></span><span class="stat-index">0<?= $statIndex ?></span></div><strong><?= e($value) ?></strong><div class="stat-bottom"><span class="stat-line"></span><span>SMAN 1 PAREPARE</span></div></article><?php endforeach; ?></section>
<details class="password-settings"><summary>Ganti password akun</summary><form method="post" class="form-stack compact-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="change_password"><label>Password saat ini</label><input name="current_password" type="password" autocomplete="current-password" required><label>Password baru (minimal 8 karakter)</label><input name="new_password" type="password" minlength="8" autocomplete="new-password" required><label>Ulangi password baru</label><input name="confirm_password" type="password" minlength="8" autocomplete="new-password" required><button class="button button-dark" type="submit">Simpan password</button></form></details>

<?php if ($admin): ?>
<section class="section-block" id="student-account"><div class="section-heading"><div><p class="eyebrow">AKSES KELAS</p><h2>Buat akun siswa</h2></div></div><div class="student-account-layout"><div class="surface student-account-panel"><div class="surface-heading"><div><h3>Identitas masuk siswa</h3><p>Akun langsung ditambahkan ke kelas yang dipilih.</p></div><span class="surface-mark">+</span></div><form method="post" class="form-stack compact-form student-account-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="create_student_account"><label for="student-name">Nama lengkap</label><input id="student-name" name="student_name" maxlength="120" autocomplete="name" required><label for="student-username">Username</label><input id="student-username" name="student_username" minlength="3" maxlength="60" pattern="[A-Za-z]{3,60}" autocomplete="off" required><span class="field-hint">3-60 huruf, tanpa angka atau spasi.</span><label for="student-password">Password</label><input id="student-password" name="student_password" type="password" minlength="8" maxlength="128" autocomplete="new-password" required><label for="student-class">Kelas / rombel</label><select id="student-class" name="class_id" required><?php foreach ($classes as $class): ?><option value="<?= (int) $class['id'] ?>"><?= e($class['name'] . ' · ' . $class['academic_year']) ?></option><?php endforeach; ?></select><button class="button button-dark" type="submit" <?= !$classes ? 'disabled' : '' ?>>Buat akun siswa <span aria-hidden="true">↗</span></button></form></div><aside class="student-account-note"><span class="school-stamp">01</span><p>Akun memiliki akses <strong>Siswa</strong> dan hanya terhubung ke kelas pilihan.</p><small>Password disimpan sebagai hash. Username yang sudah dipakai tidak dapat digunakan kembali.</small></aside></div></section>
<section class="section-block" id="bulk-students"><div class="section-heading"><div><p class="eyebrow">ENROLMENT SISWA</p><h2>Tambah siswa ke kelas</h2></div></div><div class="workspace-grid"><div class="surface bulk-import-panel"><div class="surface-heading"><div><h3>Impor akun siswa</h3><p>Username dibuat dari nama lengkap, hanya huruf.</p></div><span class="surface-mark">36</span></div><form method="post" class="form-stack compact-form bulk-import-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="bulk_student_accounts"><label>Kelas / rombel</label><select name="class_id" required><?php foreach ($classes as $class): ?><option value="<?= (int) $class['id'] ?>"><?= e($class['name'] . ' · ' . $class['academic_year']) ?></option><?php endforeach; ?></select><label>Daftar siswa</label><textarea name="student_rows" rows="12" placeholder="NAMA LENGKAP | 10 digit password" required></textarea><p class="form-hint">Satu siswa per baris, format: nama lengkap | password 10 digit. Password disimpan sebagai hash.</p><button class="button button-dark" type="submit" <?= !$classes ? 'disabled' : '' ?>>Buat akun & masukkan ke kelas</button></form></div><div class="bulk-import-note"><span class="school-stamp">ID</span><p>Akun akan memiliki role <strong>Siswa</strong>, dengan akses tugas, materi, pengumpulan, dan nilai hanya untuk kelas yang dipilih.</p><small>Akun yang sudah ada tidak direset. Jika username sudah dipakai akun lain, seluruh batch dibatalkan.</small></div></div></section>
<section class="section-block" id="users"><div class="section-heading"><div><p class="eyebrow">AKSES SEKOLAH</p><h2>Pengguna</h2></div><span class="section-count"><?= count($users) ?> akun</span></div><div class="workspace-grid"><div class="surface table-surface"><div class="surface-heading"><div><h3>Daftar akun</h3><p>Kelola akses guru dan siswa.</p></div><span class="surface-mark">01</span></div><div class="table-scroll"><table data-searchable><thead><tr><th>Nama</th><th>Username</th><th>Peran</th><th>Aksi</th></tr></thead><tbody><?php foreach ($users as $account): ?><tr><td class="name-cell"><?= e($account['name']) ?></td><td><?= e($account['username']) ?></td><td><span class="role-pill role-<?= e($account['role']) ?>"><?= e($account['role'] === 'teacher' ? 'Guru' : ($account['role'] === 'student' ? 'Siswa' : 'Admin')) ?></span></td><td><?php if ($account['role'] !== 'admin'): ?><details class="inline-edit"><summary>Edit</summary><form method="post" class="mini-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="update_user"><input type="hidden" name="user_id" value="<?= (int) $account['id'] ?>"><label>Nama<input name="name" value="<?= e($account['name']) ?>" required></label><label>Username<input name="username" value="<?= e($account['username']) ?>" required></label><label>Password baru<input name="password" type="password" minlength="8" placeholder="Kosongkan jika tetap"></label><label>Peran<select name="role"><option value="teacher" <?= $account['role'] === 'teacher' ? 'selected' : '' ?>>Guru</option><option value="student" <?= $account['role'] === 'student' ? 'selected' : '' ?>>Siswa</option></select></label><button class="button button-dark" type="submit">Simpan</button></form></details><form method="post" class="inline-form" data-confirm="Hapus akun ini? Data yang masih memiliki relasi tidak dapat dihapus."><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete_user"><input type="hidden" name="user_id" value="<?= (int) $account['id'] ?>"><button class="text-danger" type="submit">Hapus</button></form><?php else: ?>—<?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div></div><div class="surface form-surface"><div class="surface-heading"><div><h3>Tambah akun</h3><p>Password awal minimal 8 karakter.</p></div><span class="surface-mark">+</span></div><form method="post" class="form-stack compact-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="create_user"><label>Nama lengkap</label><input name="name" maxlength="120" required><label>Username</label><input name="username" minlength="3" maxlength="60" pattern="[A-Za-z0-9._-]+" required><label>Password awal</label><input name="password" type="password" minlength="8" required><label>Peran</label><select name="role"><option value="teacher">Guru</option><option value="student">Siswa</option></select><button class="button button-dark" type="submit">Buat akun</button></form></div></div></section>

<section class="section-block" id="classes"><div class="section-heading"><div><p class="eyebrow">ROMBONGAN BELAJAR</p><h2>Kelas & siswa</h2></div><span class="section-count"><?= count($classes) ?> kelas</span></div><div class="workspace-grid"><div class="surface table-surface"><div class="surface-heading"><div><h3>Kelas terdaftar</h3><p>Kelola rombel dan keanggotaan siswa.</p></div></div><div class="table-scroll"><table data-searchable><thead><tr><th>Kelas</th><th>Kode</th><th>Tahun ajaran</th><th>Siswa</th><th>Aksi</th></tr></thead><tbody><?php foreach ($classes as $class): ?><tr><td class="name-cell"><?= e($class['name']) ?></td><td><?= e($class['code']) ?></td><td><?= e($class['academic_year']) ?></td><td><?= (int) $class['student_count'] ?></td><td><details class="inline-edit"><summary>Kelola</summary><div class="class-editor"><form method="post" class="mini-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_class"><input type="hidden" name="class_id" value="<?= (int) $class['id'] ?>"><label>Nama<input name="name" value="<?= e($class['name']) ?>" required></label><label>Kode<input name="code" value="<?= e($class['code']) ?>" required></label><label>Tahun ajaran<input name="academic_year" value="<?= e($class['academic_year']) ?>" pattern="\d{4}/\d{4}" required></label><button class="button button-dark" type="submit">Simpan kelas</button></form><form method="post" class="mini-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="set_class_students"><input type="hidden" name="class_id" value="<?= (int) $class['id'] ?>"><strong>Anggota siswa</strong><?php $memberQuery = $pdo->prepare('SELECT student_id FROM class_students WHERE class_id = ?'); $memberQuery->execute([$class['id']]); $memberIds = array_map('intval', $memberQuery->fetchAll(PDO::FETCH_COLUMN)); foreach ($students as $studentOption): ?><label class="check-row"><input type="checkbox" name="student_ids[]" value="<?= (int) $studentOption['id'] ?>" <?= in_array((int) $studentOption['id'], $memberIds, true) ? 'checked' : '' ?>><?= e($studentOption['name']) ?></label><?php endforeach; ?><button class="button button-outline" type="submit">Simpan anggota</button></form></div></details><form method="post" class="inline-form" data-confirm="Hapus kelas beserta relasi kelasnya?"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete_class"><input type="hidden" name="class_id" value="<?= (int) $class['id'] ?>"><button class="text-danger" type="submit">Hapus</button></form></td></tr><?php endforeach; ?></tbody></table></div></div><div class="surface form-surface"><div class="surface-heading"><div><h3>Tambah kelas</h3><p>Contoh format kode: X-RPL-1.</p></div><span class="surface-mark">+</span></div><form method="post" class="form-stack compact-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_class"><label>Nama kelas</label><input name="name" placeholder="X RPL 1" required><label>Kode kelas</label><input name="code" placeholder="X-RPL-1" required><label>Tahun ajaran</label><input name="academic_year" value="2026/2027" pattern="\d{4}/\d{4}" required><button class="button button-dark" type="submit">Tambah kelas</button></form></div></div></section>

<section class="section-block" id="subjects"><div class="section-heading"><div><p class="eyebrow">KURIKULUM</p><h2>Mata pelajaran & penugasan</h2></div><span class="section-count"><?= count($subjects) ?> mapel</span></div><div class="workspace-grid"><div class="surface table-surface"><div class="surface-heading"><div><h3>Mata pelajaran</h3><p>Atur mapel dan guru pengampu per kelas.</p></div></div><div class="table-scroll"><table data-searchable><thead><tr><th>Mapel</th><th>Kode</th><th>Aksi</th></tr></thead><tbody><?php foreach ($subjects as $subject): ?><tr><td class="name-cell"><?= e($subject['name']) ?></td><td><?= e($subject['code']) ?></td><td><details class="inline-edit"><summary>Edit</summary><form method="post" class="mini-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_subject"><input type="hidden" name="subject_id" value="<?= (int) $subject['id'] ?>"><label>Nama<input name="name" value="<?= e($subject['name']) ?>" required></label><label>Kode<input name="code" value="<?= e($subject['code']) ?>" required></label><button class="button button-dark" type="submit">Simpan</button></form></details><form method="post" class="inline-form" data-confirm="Hapus mata pelajaran ini?"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete_subject"><input type="hidden" name="subject_id" value="<?= (int) $subject['id'] ?>"><button class="text-danger" type="submit">Hapus</button></form></td></tr><?php endforeach; ?></tbody></table></div><div class="surface-heading assignment-map-heading"><div><h3>Guru · kelas · mapel</h3><p>Relasi penugasan aktif.</p></div></div><div class="table-scroll"><table data-searchable><thead><tr><th>Guru</th><th>Kelas</th><th>Mapel</th><th></th></tr></thead><tbody><?php foreach ($teacherAssignments as $mapping): ?><tr><td><?= e($mapping['teacher_name']) ?></td><td><?= e($mapping['class_name']) ?></td><td><?= e($mapping['subject_name']) ?></td><td><form method="post" data-confirm="Hapus penugasan ini?"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete_teacher_assignment"><input type="hidden" name="teacher_assignment_id" value="<?= (int) $mapping['id'] ?>"><button class="text-danger" type="submit">Hapus</button></form></td></tr><?php endforeach; ?></tbody></table></div></div><div class="surface form-surface"><div class="surface-heading"><div><h3>Tambah mata pelajaran</h3><p>Hubungkan guru dengan kelas dan mapel.</p></div><span class="surface-mark">+</span></div><form method="post" class="form-stack compact-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_subject"><label>Nama mata pelajaran</label><input name="name" placeholder="Bahasa Inggris" required><label>Kode mapel</label><input name="code" placeholder="BING" required><button class="button button-outline" type="submit">Simpan mapel</button></form><form method="post" class="form-stack compact-form map-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="assign_teacher"><label>Guru</label><select name="teacher_id" required><option value="">Pilih guru</option><?php foreach ($teachers as $option): ?><option value="<?= (int) $option['id'] ?>"><?= e($option['name']) ?></option><?php endforeach; ?></select><label>Kelas</label><select name="class_id" required><option value="">Pilih kelas</option><?php foreach ($classes as $option): ?><option value="<?= (int) $option['id'] ?>"><?= e($option['name']) ?> · <?= e($option['academic_year']) ?></option><?php endforeach; ?></select><label>Mata pelajaran</label><select name="subject_id" required><option value="">Pilih mapel</option><?php foreach ($subjects as $option): ?><option value="<?= (int) $option['id'] ?>"><?= e($option['name']) ?></option><?php endforeach; ?></select><button class="button button-dark" type="submit">Tugaskan guru</button></form></div></div></section>

<section class="section-block" id="assignments"><div class="section-heading"><div><p class="eyebrow">MONITORING</p><h2>Semua tugas & rekap</h2></div><span class="section-count"><?= count($assignments) ?> tugas</span></div><div class="surface table-surface"><div class="table-toolbar"><label class="search-control"><span>Cari</span><input type="search" data-table-filter placeholder="Nama tugas, kelas, guru..."></label><label>Filter status<select data-status-filter><option value="">Semua status</option><option value="Belum mengumpulkan">Belum mengumpulkan</option><option value="Sudah mengumpulkan — tepat waktu">Tepat waktu</option><option value="Terlambat">Terlambat</option><option value="Sudah dinilai">Sudah dinilai</option></select></label></div><div class="table-scroll"><table data-searchable><thead><tr><th>Tugas</th><th>Kelas / mapel</th><th>Guru</th><th>Tenggat</th><th>Pengumpulan</th><th>Status</th></tr></thead><tbody><?php foreach ($assignments as $item): ?><tr><td class="name-cell"><?= e($item['title']) ?></td><td><?= e($item['class_name']) ?> · <?= e($item['subject_name']) ?></td><td><?= e($item['teacher_name']) ?></td><td><?= e(lms_date($item['due_at'])) ?></td><td><?= (int) $item['submission_count'] ?> / <?= (int) $item['student_count'] ?></td><td><span class="status-pill <?= (int) $item['is_closed'] ? 'status-closed' : 'status-on-time' ?>"><?= (int) $item['is_closed'] ? 'Ditutup' : 'Aktif' ?></span></td></tr><?php endforeach; ?></tbody></table></div></div><div class="surface table-surface report-surface"><div class="surface-heading"><div><h3>Rekap pengumpulan & nilai</h3><p>300 aktivitas terbaru.</p></div></div><div class="table-scroll"><table data-searchable><thead><tr><th>Siswa</th><th>Tugas</th><th>Kelas / mapel</th><th>Waktu unggah</th><th>Status</th><th>Nilai</th><th>Berkas</th></tr></thead><tbody><?php foreach ($rosterRows as $item): $status = lms_status($item['submitted_at'], $item['due_at'], $item['score'] !== null && (int) $item['is_published'] === 1); ?><tr data-status="<?= e($status) ?>"><td><?= e($item['student_name']) ?></td><td><?= e($item['assignment_title']) ?></td><td><?= e($item['class_name']) ?> · <?= e($item['subject_name']) ?></td><td><?= e(lms_date($item['submitted_at'])) ?></td><td><span class="status-pill <?= e(lms_status_class($status)) ?>"><?= e($status) ?></span></td><td><?= $item['score'] !== null ? e(number_format((float) $item['score'], 1, ',', '.')) : '—' ?></td><td><?php if ($item['submission_id']): ?><a href="?download=<?= (int) $item['submission_id'] ?>&kind=submission" class="text-link">Unduh</a><?php else: ?>—<?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div></div></section>

<?php elseif ($teacher): ?>
<section class="section-block teacher-class-strip"><div class="section-heading"><div><p class="eyebrow">PENUGASAN ANDA</p><h2>Kelas & mata pelajaran</h2></div></div><div class="mapping-chips"><?php foreach ($teacherAssignments as $mapping): ?><span class="mapping-chip"><strong><?= e($mapping['class_name']) ?></strong><small><?= e($mapping['subject_name']) ?></small></span><?php endforeach; ?><?php if (!$teacherAssignments): ?><p class="muted">Belum ada kelas/mapel yang ditugaskan admin.</p><?php endif; ?></div></section>
<section class="section-block" id="materials"><div class="section-heading"><div><p class="eyebrow">DISTRIBUSI PEMBELAJARAN</p><h2>Materi Bahasa Inggris</h2></div><span class="section-count"><?= count($materials) ?> materi</span></div><div class="workspace-grid"><div class="material-list"><?php foreach ($materials as $item): ?><article class="surface material-item"><div class="material-meta"><?= e($item['class_name']) ?> · <?= e($item['subject_name']) ?> · <?= e(lms_date($item['published_at'])) ?></div><h3><?= e($item['title']) ?></h3><p><?= nl2br(e($item['description'] ?? '')) ?></p><div class="material-actions"><?php if ($item['resource_url']): ?><a class="text-link" href="<?= e($item['resource_url']) ?>" target="_blank" rel="noopener noreferrer">Buka tautan ↗</a><?php endif; ?><?php if ($item['file_stored']): ?><a class="text-link" href="?download=<?= (int) $item['id'] ?>&kind=material">Unduh <?= e($item['file_original']) ?> ↓</a><?php endif; ?><form method="post" data-confirm="Hapus materi ini?"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete_material"><input type="hidden" name="material_id" value="<?= (int) $item['id'] ?>"><button class="text-danger" type="submit">Hapus</button></form></div></article><?php endforeach; ?><?php if (!$materials): ?><div class="surface empty-state"><p>Belum ada materi dibagikan.</p></div><?php endif; ?></div><div class="surface form-surface"><div class="surface-heading"><div><h3>Bagikan materi</h3><p>Unggah berkas, tautan, atau keduanya.</p></div></div><?php if ($teacherAssignments): ?><form method="post" enctype="multipart/form-data" class="form-stack compact-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_material"><label>Kelas & mata pelajaran</label><select name="teacher_assignment_id" required><?php foreach ($teacherAssignments as $mapping): ?><option value="<?= (int) $mapping['id'] ?>"><?= e($mapping['class_name'] . ' · ' . $mapping['subject_name']) ?></option><?php endforeach; ?></select><label>Judul materi</label><input name="title" maxlength="180" required><label>Deskripsi</label><textarea name="description" rows="3"></textarea><label>Tautan</label><input name="resource_url" type="url" placeholder="https://..."><label>Berkas (opsional, maks. 10 MB)</label><input name="material_file" type="file" accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.jpg,.jpeg,.png"><button class="button button-dark" type="submit">Publikasikan materi</button></form><?php else: ?><div class="empty-state"><p>Minta admin menetapkan kelas dan mata pelajaran.</p></div><?php endif; ?></div></div></section>
<section class="section-block" id="assignments"><div class="section-heading"><div><p class="eyebrow">KELOLA KEGIATAN</p><h2>Tugas</h2></div><span class="section-count"><?= count($assignments) ?> tugas</span></div><div class="workspace-grid teacher-grid"><div class="assignment-list"><?php foreach ($assignments as $item): ?><article class="surface task-manage"><div class="task-title-row"><div><div class="material-meta"><?= e($item['class_name']) ?> · <?= e($item['subject_name']) ?></div><h3><?= e($item['title']) ?></h3></div><span class="status-pill <?= (int) $item['is_closed'] ? 'status-closed' : 'status-on-time' ?>"><?= (int) $item['is_closed'] ? 'Ditutup' : 'Aktif' ?></span></div><p><?= nl2br(e($item['description'])) ?></p><div class="task-facts"><span>Tenggat <strong><?= e(lms_date($item['due_at'])) ?></strong></span><span>Bobot <strong><?= e($item['weight']) ?>%</strong></span><span>Pengumpulan <strong><?= (int) $item['submission_count'] ?>/<?= (int) $item['student_count'] ?></strong></span></div><?php if ($item['attachment_stored']): ?><a class="text-link" href="?download=<?= (int) $item['id'] ?>&kind=assignment">Lampiran: <?= e($item['attachment_original']) ?> ↓</a><?php endif; ?><div class="task-actions"><?php if (!(int) $item['is_closed']): ?><details class="inline-edit"><summary>Edit tugas</summary><form method="post" enctype="multipart/form-data" class="form-stack compact-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_assignment"><input type="hidden" name="assignment_id" value="<?= (int) $item['id'] ?>"><label>Kelas / mapel</label><select name="teacher_assignment_id"><?php foreach ($teacherAssignments as $mapping): ?><option value="<?= (int) $mapping['id'] ?>" <?= (int) $mapping['id'] === (int) $item['mapping_id'] ? 'selected' : '' ?>><?= e($mapping['class_name'] . ' · ' . $mapping['subject_name']) ?></option><?php endforeach; ?></select><label>Judul</label><input name="title" value="<?= e($item['title']) ?>" required><label>Instruksi</label><textarea name="description" rows="3" required><?= e($item['description']) ?></textarea><label>Tenggat</label><input name="due_at" type="datetime-local" value="<?= $item['due_at'] ? e(date('Y-m-d\TH:i', strtotime($item['due_at']))) : '' ?>"><label>Bobot</label><input name="weight" type="number" min="0.01" max="1000" step="0.01" value="<?= e($item['weight']) ?>" required><label>Lampiran pengganti (opsional)</label><input name="assignment_file" type="file" accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.jpg,.jpeg,.png"><label class="check-row"><input type="checkbox" name="allow_late" <?= (int) $item['allow_late'] ? 'checked' : '' ?>>Terima pengumpulan terlambat</label><label class="check-row"><input type="checkbox" name="allow_resubmit_after_due" <?= (int) $item['allow_resubmit_after_due'] ? 'checked' : '' ?>>Izinkan revisi setelah tenggat</label><button class="button button-dark" type="submit">Simpan perubahan</button></form></details><form method="post" data-confirm="Tutup tugas? Siswa tidak dapat mengunggah setelah tugas ditutup."><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="close_assignment"><input type="hidden" name="assignment_id" value="<?= (int) $item['id'] ?>"><button class="text-danger" type="submit">Tutup tugas</button></form><?php endif; ?></div></article><?php endforeach; ?><?php if (!$assignments): ?><div class="surface empty-state"><p>Belum ada tugas diterbitkan.</p></div><?php endif; ?></div><div class="surface form-surface"><div class="surface-heading"><div><h3>Terbitkan tugas</h3><p>Tenggat dicatat dalam WITA.</p></div></div><?php if ($teacherAssignments): ?><form method="post" enctype="multipart/form-data" class="form-stack compact-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_assignment"><label>Kelas / mata pelajaran</label><select name="teacher_assignment_id" required><?php foreach ($teacherAssignments as $mapping): ?><option value="<?= (int) $mapping['id'] ?>"><?= e($mapping['class_name'] . ' · ' . $mapping['subject_name']) ?></option><?php endforeach; ?></select><label>Judul tugas</label><input name="title" maxlength="180" required><label>Instruksi</label><textarea name="description" rows="4" required></textarea><label>Tenggat pengumpulan</label><input name="due_at" type="datetime-local"><label>Bobot (%)</label><input name="weight" type="number" min="0.01" max="1000" step="0.01" value="100" required><label>Lampiran (opsional)</label><input name="assignment_file" type="file" accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.jpg,.jpeg,.png"><label class="check-row"><input type="checkbox" name="allow_late" checked>Terima pengumpulan terlambat</label><label class="check-row"><input type="checkbox" name="allow_resubmit_after_due">Izinkan revisi setelah tenggat</label><button class="button button-dark" type="submit">Terbitkan tugas</button></form><?php else: ?><div class="empty-state"><p>Belum ada penugasan guru.</p></div><?php endif; ?></div></div></section>
<section class="section-block" id="submissions"><div class="section-heading"><div><p class="eyebrow">KOREKSI & UMPAN BALIK</p><h2>Pengumpulan siswa</h2></div><span class="section-count"><?= count($rosterRows) ?> baris daftar kelas</span></div><div class="surface table-surface"><div class="table-toolbar"><label class="search-control"><span>Cari siswa/tugas</span><input type="search" data-table-filter placeholder="Ketik nama..."></label><label>Filter status<select data-status-filter><option value="">Semua status</option><option value="Belum mengumpulkan">Belum mengumpulkan</option><option value="Sudah mengumpulkan — tepat waktu">Tepat waktu</option><option value="Terlambat">Terlambat</option><option value="Sudah dinilai">Sudah dinilai</option></select></label></div><div class="table-scroll"><table data-searchable><thead><tr><th>Siswa</th><th>Tugas</th><th>Kelas / mapel</th><th>Waktu unggah</th><th>Status</th><th>Berkas</th><th>Nilai & umpan balik</th></tr></thead><tbody><?php foreach ($rosterRows as $item): $graded = $item['score'] !== null && (int) $item['is_published'] === 1; $status = lms_status($item['submitted_at'], $item['due_at'], $graded); ?><tr data-status="<?= e($status) ?>"><td><?= e($item['student_name']) ?></td><td><?= e($item['assignment_title']) ?></td><td><?= e($item['class_name']) ?> · <?= e($item['subject_name']) ?></td><td><?= e(lms_date($item['submitted_at'])) ?></td><td><span class="status-pill <?= e(lms_status_class($status)) ?>"><?= e($status) ?></span></td><td><?php if ($item['submission_id']): ?><a class="text-link" href="?download=<?= (int) $item['submission_id'] ?>&kind=submission">Unduh</a><?php else: ?>—<?php endif; ?></td><td><?php if ($item['submission_id']): ?><details class="grade-editor"><summary><?= $item['score'] === null ? 'Beri nilai' : 'Nilai: ' . e(number_format((float) $item['score'], 1, ',', '.')) ?></summary><form method="post" class="mini-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="grade_submission"><input type="hidden" name="submission_id" value="<?= (int) $item['submission_id'] ?>"><label>Nilai (0–100)<input name="score" type="number" min="0" max="100" step="0.01" value="<?= $item['score'] !== null ? e($item['score']) : '' ?>" required></label><label>Umpan balik<textarea name="feedback" rows="3" maxlength="4000"><?= e($item['feedback'] ?? '') ?></textarea></label><label class="check-row"><input type="checkbox" name="is_published" <?= $item['score'] === null || (int) $item['is_published'] ? 'checked' : '' ?>>Publikasikan ke siswa</label><button class="button button-dark" type="submit">Simpan nilai</button></form><?php else: ?>—<?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div></div></section>

<?php else: ?>
<section class="section-block" id="materials"><div class="section-heading"><div><p class="eyebrow">BAHAN BELAJAR</p><h2>Materi Bahasa Inggris</h2></div><span class="section-count"><?= count($materials) ?> materi</span></div><div class="material-list student-materials"><?php foreach ($materials as $item): ?><article class="surface material-item"><div class="material-meta"><?= e($item['class_name']) ?> · <?= e($item['subject_name']) ?> · <?= e(lms_date($item['published_at'])) ?></div><h3><?= e($item['title']) ?></h3><p><?= nl2br(e($item['description'] ?? '')) ?></p><div class="material-actions"><?php if ($item['resource_url']): ?><a class="text-link" href="<?= e($item['resource_url']) ?>" target="_blank" rel="noopener noreferrer">Buka tautan ↗</a><?php endif; ?><?php if ($item['file_stored']): ?><a class="text-link" href="?download=<?= (int) $item['id'] ?>&kind=material">Unduh <?= e($item['file_original']) ?> ↓</a><?php endif; ?></div></article><?php endforeach; ?><?php if (!$materials): ?><div class="surface empty-state"><p>Belum ada materi dibagikan untuk kelasmu.</p></div><?php endif; ?></div></section>
<section class="section-block" id="assignments"><div class="section-heading"><div><p class="eyebrow">TENGGAT & STATUS</p><h2>Tugas saya</h2></div><span class="section-count"><?= count($assignments) ?> tugas</span></div><div class="table-toolbar standalone-toolbar"><label class="search-control"><span>Cari tugas/mapel</span><input type="search" data-table-filter placeholder="Ketik judul..."></label><label>Filter status<select data-status-filter><option value="">Semua status</option><option value="Belum mengumpulkan">Belum mengumpulkan</option><option value="Sudah mengumpulkan — tepat waktu">Tepat waktu</option><option value="Terlambat">Terlambat</option><option value="Sudah dinilai">Sudah dinilai</option></select></label></div><div class="assignment-list" data-assignment-list><?php foreach ($assignments as $item): $isGraded = $item['score'] !== null && (int) $item['is_published'] === 1; $status = lms_status($item['submitted_at'], $item['due_at'], $isGraded); ?><article class="surface assignment-item" data-status="<?= e($status) ?>"><div class="assignment-main"><div class="assignment-code"><?= e($item['subject_code']) ?></div><div class="assignment-copy"><div class="assignment-meta"><span><?= e($item['class_name']) ?> · <?= e($item['subject_name']) ?></span><span class="meta-separator">·</span><span>Guru <?= e($item['teacher_name']) ?></span></div><h3><?= e($item['title']) ?></h3><p><?= nl2br(e($item['description'])) ?></p><div class="assignment-due"><span class="due-dot <?= $item['due_at'] && strtotime($item['due_at']) < time() ? 'due-late' : '' ?>"></span>Tenggat: <?= e(lms_date($item['due_at'])) ?></div><span class="task-weight">Bobot <?= e($item['weight']) ?>%</span><?php if ($item['attachment_stored']): ?><a class="text-link" href="?download=<?= (int) $item['id'] ?>&kind=assignment">Lampiran tugas: <?= e($item['attachment_original']) ?> ↓</a><?php endif; ?></div></div><div class="assignment-submit"><span class="status-pill <?= e(lms_status_class($status)) ?>"><?= e($status) ?></span><?php if ($item['submission_id']): ?><div class="submitted-file"><span class="file-chip">FILE</span><span><strong><?= e($item['file_original']) ?></strong><small>Dikirim <?= e(lms_date($item['submitted_at'])) ?> · Revisi <?= (int) $item['revision_count'] ?></small></span><a class="download-link" href="?download=<?= (int) $item['submission_id'] ?>&kind=submission" aria-label="Unduh berkas sendiri">↓</a></div><?php endif; ?><?php if ($isGraded): ?><div class="student-grade"><span>Nilai akhir</span><strong><?= e(number_format((float) $item['score'], 1, ',', '.')) ?><small> / 100</small></strong></div><?php elseif ($item['score'] !== null): ?><span class="status-pill status-not-submitted">Menunggu publikasi nilai</span><?php endif; ?><?php if (!(int) $item['is_closed'] && (!(int) $item['allow_late'] ? (!$item['due_at'] || strtotime($item['due_at']) >= time()) : true) && (!$item['submission_id'] || !$item['due_at'] || strtotime($item['due_at']) >= time() || (int) $item['allow_resubmit_after_due'])): ?><form method="post" enctype="multipart/form-data" class="upload-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="submit_assignment"><input type="hidden" name="assignment_id" value="<?= (int) $item['id'] ?>"><label class="upload-control"><input type="file" name="submission_file" accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.jpg,.jpeg,.png" required><span><?= $item['submission_id'] ? 'Pilih revisi' : 'Pilih berkas' ?></span></label><button class="button button-dark" type="submit"><?= $item['submission_id'] ? 'Unggah revisi' : 'Kumpulkan' ?></button><small>PDF, Office, JPG, PNG · Maks. 10 MB</small></form><?php endif; ?><?php if ($isGraded && trim((string) $item['feedback']) !== ''): ?><div class="feedback-note"><span>UMPAN BALIK GURU</span><p><?= nl2br(e($item['feedback'])) ?></p></div><?php endif; ?></div></article><?php endforeach; ?><?php if (!$assignments): ?><div class="surface empty-state"><p>Belum ada tugas untuk kelasmu.</p></div><?php endif; ?></div></section>
<section class="section-block grade-history" id="grades"><div class="section-heading"><div><p class="eyebrow">HASIL BELAJAR</p><h2>Nilai saya</h2></div><span class="section-count"><?= count($graded) ?> nilai dipublikasikan</span></div><div class="surface table-surface"><div class="table-scroll"><table data-searchable><thead><tr><th>Tugas</th><th>Kelas / mapel</th><th>Waktu dinilai</th><th>Nilai</th><th>Umpan balik</th></tr></thead><tbody><?php foreach ($assignments as $item): if ($item['score'] === null || !(int) $item['is_published']) { continue; } ?><tr><td class="name-cell"><?= e($item['title']) ?></td><td><?= e($item['class_name']) ?> · <?= e($item['subject_name']) ?></td><td><?= e(lms_date($item['graded_at'])) ?></td><td><span class="score-badge"><?= e(number_format((float) $item['score'], 1, ',', '.')) ?></span></td><td><?= trim((string) $item['feedback']) !== '' ? e($item['feedback']) : '—' ?></td></tr><?php endforeach; ?></tbody></table></div></div></section>
<?php endif; ?>
<footer class="app-footer"><span>SMAN 1 PAREPARE · LMS ENGLISH</span><span>© <?= e(date('Y')) ?> <b>·</b> WITA</span></footer></div></main></div><div class="sidebar-scrim" id="sidebar-scrim"></div><script src="assets/app.js" defer></script></body></html>